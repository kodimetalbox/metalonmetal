import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_big_concerts

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


arrayMenu = ([
            [ "Best Ever Live Shows",                "PLGuhlLazJwGt3wCs25kb0XHh8eKLXRaw5"],
            [ "Thrash",                              "PLGuhlLazJwGuyYQmfyKvPdWhlGjrmGoDi"],
            [ "Crossover",         				     "PLGuhlLazJwGvhQQFZQAJ3pPHSxTHyfKZQ"],
            [ "Heavy Metal",                         "PLGuhlLazJwGv4DB17y4bLryuQ91sE7bMV"],
            [ "Power Metal",                         "PLGuhlLazJwGs3wndsYWNbfAcQaNSnpq69"],            
            [ "Symphonic",                           "PLGuhlLazJwGtCFRbM69jzt7Qj4BtMw0Jt"],
            [ "Gothic & Doom",                       "PLGuhlLazJwGsqpKehaXZA8JiYgLk3sW8S"],
            [ "Melodic Death",                       "PLGuhlLazJwGu0TkjTH1qq96ezBDfMuUaM"],
            [ "Rock",                                "PLGuhlLazJwGsmHMWjAxBtc8OuYR--WmiV"],
            [ "Spanish Bands",                       "PLGuhlLazJwGvD8MWoPFfa9DysflL_6UIN"],
            [ "Punk Rock",                           "PLGuhlLazJwGu3lYKfD5-uwd1wH3G2xm-f"], 
            [ "Progressive",                         "PLGuhlLazJwGvojJQvDXZHD98X76Z1lrCl"],
            [ "Shred",                         		 "PLGuhlLazJwGuv1wmXmRSh85094GxNOAAY"],  
            [ "AOR & Glam",                          "PLGuhlLazJwGuEu1G_0RlBH8EApI4u9kfH"],
            [ "Extreme",                             "PLGuhlLazJwGuIujhUZRDrrZLox9d1u9i6"],          
            [ "Black Metal",                         "PLGuhlLazJwGuaXJtg9xqK6xJVASl0meUQ"]
            ])

def playlists(params):
    logo=logos_big_concerts.full_concerts(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





