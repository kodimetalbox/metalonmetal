import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_big_concerts

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


arrayMenu = ([
			[ "2024 Live Videos","PLJvQXRgtxlumdSu6j1m2myyZ7KKHgBuel"],
			[ "2023 Live Videos","PLJvQXRgtxlumx7ph86EvYQzCamEyLIICI"],
			[ "M72 World Tour Videos","PLJvQXRgtxlukmDarotT2ZFhjAVYdQHSka"],
            [ "72 Seasons - The Videos", "PLJvQXRgtxlukgeGWeUGjqMDb8_ZkuHY45"],
            [ "72 Seasons - Lyric Videos", "PLJvQXRgtxlulzHS5D8dXaVpy0g7R5TYPn"],
            [ "Death Magnetic Metallica Subtitulado Al Español - HQ Audio", "PLFtUfRNQ_TAFcd59OArM_SOo1SHrvmmnE"],
			[ "Metallica's Official Music Videos","PL2D4A44B959D87893"],
            [ "Metallica official videos", "PLu4MgpU37kMeo9l9atCzPPV_gNbcAadDK"],
            [ "Metallica What If... Series", "PL1NGIGdRe_zbLrN5IsehAGQTNGmuVwlYv"],
            [ "Metallica Soundboard Recordings", "PLhzHGRs8zyWhtHY4vNm6I2NyxklpCSShV"],
            [ "Metallica - Best Live Performances", "PLBOoL9TKvGzAVm1B3DxBhILbGwW1zaywx"],
            [ "Metallica Cliff Burton LOUD Bass", "PLbooyLdDuJOvf4tTkhM-cqHtQ8vfgAMZF"],
            [ "Metallica Loud Bass - Jason Newsted Era", "PLbooyLdDuJOuz6bAS85oCQqEblxLk7A-V"],
            [ "Official Videos", "PL2D4A44B959D87893"],
            [ "Metallica Mondays", "PLJvQXRgtxlukIkmzucaV3rSFgYYdTr85A"],
            [ "Concerts WorldWired Tour", "PLGuhlLazJwGuLED6lwpyrz1Qigq2K4ysf"],  
            [ "2022 Live Videos", "PLJvQXRgtxlulvBZ6oFu0kqPEEz1VpVXJr"],           
            [ "2021 Live Videos", "PLJvQXRgtxlumrVpfvz6ARcKltF19ixO6q"], 
            [ "Top 25 Live in 2019 - Videos of the Year", "PLJvQXRgtxlumTgSFCMV3aPajZrG-84ezO"],           
            [ "30 Years of Justice", "PLJvQXRgtxlunkS2-zHiqHrdYwpf7pFQmc"],
			[ "WorldWired Videos 2016-2019","PLJvQXRgtxluml0XI5bcvTTzsxE9b7hrWC"], 
            [ "Videos 2018 On Tour", "PLJvQXRgtxlunwsDH0dKcz-76r-4PqtIZH"],           
            [ "Videos 2017 On Tour", "PLJvQXRgtxlumwtxmRqBqQ9bWqW2Rkkxll"], 
			[ "WorldWired European Tour (2017-2018)","PLJvQXRgtxlunqL4BWfSWEpnk5a7_e9_Bn"],
            [ "Hardwired...To Self-Destruct - Videos", "PLJvQXRgtxlumAHceNRk3cx3P7MZVUCdBl"], 
            [ "Videos WorldWired Tour", "PLJvQXRgtxluml0XI5bcvTTzsxE9b7hrWC"],
            [ "Videos WorldWired Euopean Tour 2017-18", "PLJvQXRgtxlunqL4BWfSWEpnk5a7_e9_Bn"],
            [ "Live Shows", "PLGuhlLazJwGvnnIDcotsbLr6F6Ku9Whrv"],
			[ "The Metallica Blacklist","PLJvQXRgtxlumMmvPbnQInIkTaKFPh0k1I"],
			[ "The 30th Annual Bridge School Benefit","PLJvQXRgtxlukDpWfqXJtW2iwQstC3X519"],
			[ "2016 Live Videos","PLJvQXRgtxlun-zK25mZd9Wne2fcVazKb9"],
			[ "2015 Live Videos","PLJvQXRgtxlunxKKa8RRQflQXFNwWr-K90"],
			[ "2014 Live Videos","PLJvQXRgtxlulYgB1tznRR0h8biN2QCiM7"],
			[ "2013 Live Videos","PLJvQXRgtxlumBahwFmTebUriuGh7__lBT"],
			[ "Orion Music + More 2013","PLJvQXRgtxlumQTbNWplt29WN0WDFVlWHB"],
			[ "2012 Live Videos","PLJvQXRgtxlun4RQOtjXljjBfbqWiKV3Ea"],
			[ "Orion Music + More 2012","PLAF970E951696D5BB"],
			[ "2011 Live Videos","PLJvQXRgtxlunOv6RNwvrgF3TQF43kOYgh"],
			[ "2010 Live Videos","PLJvQXRgtxlunGlpcd-grePnkR7UNtwW-Z"],
			[ "2009 Live Videos","PLJvQXRgtxlun1kuBPU3-X51H879QIAMz4"],
			[ "2008 Live Videos","PLJvQXRgtxlunGxi4Pt23B25KVlfZAMVt7"],
			[ "2007 Live Videos","PLJvQXRgtxlulpZibo45rlcA7Wlyu7VOY5"],
			[ "2005-06 Live Videos","PLJvQXRgtxluld8drC1wxIhqRLYdyBajDU"],
			[ "2004 Live Videos","PLJvQXRgtxlulvf0iE78KK-KrIUF1e-IRD"],
			[ "2003 Live Videos","PLJvQXRgtxlukev9_G6fqz2DZvEh9sHK-m"],
			[ "Full Albums played Live","PLjpeJUznGUbv0I8hH15zpKf3xkCuN6sWH"],
			[ "Metallica Full Albums Live","PLj31ibB-QfXkqmSN2nkYb3Wq2vDiCGvYx"],
			[ "Rare Metallica Songs Played Live","PLjpeJUznGUbtphTa-uDJJ3ox7i2JDSJ4q"],
			[ "Documentaries / Making-Of's & Behind The Scenes","PLjpeJUznGUbv694iPasTzNlDGnjtSvDPa"],
            [ "Metallica Fingerstyle/Acoustic", "PLpaC8Xn1qPorVsHiZVPViyXWaIu0bJV9W"],
            [ "Metallica Acoustics Riffs", "PL2jxNREzQl6rDkuB7XzUNlNwSiLm-NMiq"],
            [ "Metal Arranged for Classical Guitar","PLFmQ71j4LFcuoyzXGV6QZvT0TEHYGJUZM"],
            [ "Metallica Flamenco Style","PLpaC8Xn1qPorm_hnZ80N4miPQk0kr9JoI"]
            ])

def playlists(params):
    logo=logos_big_concerts.metallica(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





