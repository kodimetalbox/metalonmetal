import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_big_concerts

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


arrayMenu = ([
            [ "72 Seasons - The Videos", "PLJvQXRgtxlukgeGWeUGjqMDb8_ZkuHY45"],
            [ "72 Seasons - Lyric Videos", "PLJvQXRgtxlulzHS5D8dXaVpy0g7R5TYPn"],
            [ "Death Magnetic Metallica Subtitulado Al Español - HQ Audio", "PLFtUfRNQ_TAFcd59OArM_SOo1SHrvmmnE"],
            [ "Metallica official videos", "PLu4MgpU37kMeo9l9atCzPPV_gNbcAadDK"],
            [ "Metallica What If... Series", "PL1NGIGdRe_zbLrN5IsehAGQTNGmuVwlYv"],
            [ "Metallica Soundboard Recordings", "PLhzHGRs8zyWhtHY4vNm6I2NyxklpCSShV"],
            [ "Metallica - Best Live Performances", "PLBOoL9TKvGzAVm1B3DxBhILbGwW1zaywx"],
            [ "Metallica Cliff Burton LOUD Bass", "PLbooyLdDuJOvf4tTkhM-cqHtQ8vfgAMZF"],
            [ "Metallica Loud Bass - Jason Newsted Era", "PLbooyLdDuJOuz6bAS85oCQqEblxLk7A-V"],
            [ "Official Videos", "PL2D4A44B959D87893"],
            [ "Metallica Mondays", "PLJvQXRgtxlukIkmzucaV3rSFgYYdTr85A"],
            [ "Concerts WorldWired Tour", "PLGuhlLazJwGuLED6lwpyrz1Qigq2K4ysf"],  
            [ "Videos 2022 On Tour", "PLJvQXRgtxlulvBZ6oFu0kqPEEz1VpVXJr"],           
            [ "Videos 2021 On Tour", "PLJvQXRgtxlumrVpfvz6ARcKltF19ixO6q"], 
            [ "Top 25 Live in 2019 - Videos of the Year", "PLJvQXRgtxlumTgSFCMV3aPajZrG-84ezO"],           
            [ "30 Years of Justice", "PLJvQXRgtxlunkS2-zHiqHrdYwpf7pFQmc"], 
            [ "Videos 2018 On Tour", "PLJvQXRgtxlunwsDH0dKcz-76r-4PqtIZH"],           
            [ "Videos 2017 On Tour", "PLJvQXRgtxlumwtxmRqBqQ9bWqW2Rkkxll"], 
            [ "Hardwired...To Self-Destruct - Videos", "PLJvQXRgtxlumAHceNRk3cx3P7MZVUCdBl"], 
            [ "Videos WorldWired Tour", "PLJvQXRgtxluml0XI5bcvTTzsxE9b7hrWC"],
            [ "Videos WorldWired Euopean Tour 2017-18", "PLJvQXRgtxlunqL4BWfSWEpnk5a7_e9_Bn"],
            [ "Live Shows", "PLGuhlLazJwGvnnIDcotsbLr6F6Ku9Whrv"]
            ])

def playlists(params):
    logo=logos_big_concerts.metallica(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





