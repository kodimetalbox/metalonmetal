import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_big_concerts

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


arrayMenu = ([
            [ "AC/DC",                         "PLpaC8Xn1qPoqkBSBog8UL9dCJX145X9oN"],  
            [ "Accept",                              "PLGuhlLazJwGsqskC5RY0qt8Pk0xclK14f"],
            [ "Amorphis",                         "PLGuhlLazJwGsGUAwjHr2Wj2kuhAby8mSS"], 
            [ "Angelus Apatrida",                         "PLGuhlLazJwGvLvSsyKdjl2PUqVNrThLEQ"],  
            [ "Anthrax",                         "PLGuhlLazJwGtk4iq-WCOgBmug070Z5y6b"], 
            [ "Barricada",                         "PLGuhlLazJwGuUFI8gVxJh-URgY4boSQGm"],
            [ "Crisix","PLpaC8Xn1qPoqGbqRsjmUYqtevLM9mJ4xF"],        
            [ "Evile",                         "PLGuhlLazJwGsVG1NimdOFnNhlF0-fnT8K"], 
            [ "Extremoduro",                         "PLGuhlLazJwGtcaDToMkjbR6qcWTt9qLZK"], 
            [ "Katatonia",                         "PLGuhlLazJwGvRAbE_sYi-vAkEPpdeQbxD"],             
            [ "Megadeth",                         "PLpaC8Xn1qPorwWc4p4uGbgq8G2fS4ZwQG"],   
            [ "Metallica",                         "PLGuhlLazJwGvnnIDcotsbLr6F6Ku9Whrv"],            
            [ "Power Trip",                         "PLGuhlLazJwGu12cIOPlZ_NnZaLvQsyY_6"],  
            [ "Slayer",                         "PLGuhlLazJwGuCqlz-4tOeor7I07gAaiPB"],           
            [ "Somas Cure",                         "PLGuhlLazJwGtklxRQWZaPJPgQVCEfmKrl"],   
            [ "Stratovarius - Under Flaming Winter Skies",                         "PLOmUKmHMjS3uMC5HdAZlyCHF49j0Klnp1"],   
            [ "Stravaganzza",         				     "PLGuhlLazJwGv175uuDQqqh0kxmQcwRBpI"],                     
            [ "The Wizards",                         "PLGuhlLazJwGsgWZndUVrJXTLoLfwZIvar"],
            [ "Tierra Santa",                         "PLGuhlLazJwGvg6837FBDdW69xWSAxUb8d"],                
            [ "Vhaldemar",                         "PLGuhlLazJwGs6D_KpRxi5PBjmK1d4PqGI"], 
            [ "Yngwie Malmsteen",                         "PLGuhlLazJwGthr4KO4tK-m61-NZ42ZGHI"]
            ])

def playlists(params):
    logo=logos_big_concerts.full_concerts(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





