import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_labels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Napalm Official Music Videos Playlist",  "PLidIjcybOMhxeUEXA2sj-J1kXQhon_3ER"],   
            [ "Miscellaneous Playlist",  "PLidIjcybOMhyugfPHsJJTffJhItDwx3v9"],               
            [ "Lyric Videos Playlist",  "PLidIjcybOMhyhDBwaGcehI4nXfG_05Q-S"],           
            [ "Live Videos Playlist",  "PLidIjcybOMhxjhFZemPNDfdzmjTTQsgRn"],           
            [ "Heavy fucking Metal Playlist",  "PLidIjcybOMhxU8YWXMgZnH7a2jJZoyBGD"],           
            [ "Extreme Metal Playlist",  "PLidIjcybOMhxB1DMxjTA0b9hUUY689xKG"],           
            [ "Hardcore / Metalcore / Melodic Death Metal Playlist",  "PLidIjcybOMhwtWkeHT1Onpkst_k0V6LTZ"],           
            [ "Female Fronted Metal Playlist",  "PLidIjcybOMhyL60IB_aMHRVM02z95zG6V"],           
            [ "Symphonic & Power Metal Playlist",  "PLidIjcybOMhznm5SOjGCt5wBIJMsPvr8P"],           
            [ "Hard Rock Playlist",  "PLidIjcybOMhy-o6vbZxL8UrkuKT7L3rmP"],           
            [ "Rock, Stoner Rock and more... Playlist",  "PLidIjcybOMhxD-ETO_LLUm6Jzi3AVZiSf"],           
            [ "Medieval / Folk / Pagan Playlist",  "PLidIjcybOMhybnEKS71J_sgH-FN0I3P74"],           
            [ "Full Concerts",  "PLlfqJred7Iwf80U5zNh_ED3QzSgF2oH1X"],           
            [ "Heavy Halloween Playlist",  "PLidIjcybOMhzZUft2kH0Iz0Cxp4W_Azrc"],                     
            [ "Unboxing Videos Playlist",  "PLidIjcybOMhxYKnhexQLC_WNdVatxpVDg"],           
            [ "Powerwolf",  "PLidIjcybOMhyx5Gxgm-YVpw1L9uknbmH2"],
            [ "Alestorm",  "PLidIjcybOMhwApZHia2Qb27ENbXWiK1PC"],
            [ "Jinjer",  "PLidIjcybOMhyQDmIGJglNjAQFR0BLFZ_m"],
            [ "Hammerfall",  "PLidIjcybOMhwzD1nS5t2NH--04M3AFR49"],
            [ "DevilDriver",  "PLidIjcybOMhx4w4AarRxMRpw7xmph8ou3"],
            [ "GloryHammer",  "PLidIjcybOMhwcnXrWztOFDMx3FONO7bXN"],
            [ "Kamelot",  "PLidIjcybOMhyxKHbDnIQuMqlUyZKw-dj1"],
            [ "Life of Agony",  "PLidIjcybOMhwP7D4nlrkcOeh0zlUO1z59"]])

def playlists(params):
    logo=logos_labels.napalm(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

