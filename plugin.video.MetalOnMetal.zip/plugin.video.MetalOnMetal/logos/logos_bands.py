def acdc(params):
	return "https://lh3.googleusercontent.com/pw/AL9nZEU87aeB3kr60zJ5Da5LwFxMpwVRlz_hrpb7xYGiRNVsQlCmgLQR6KsCLJuxosspiq9GlufZvcfmEtXaCYWQz8_ZkmbQi-NvmdGvhpt2f1VEQacLGbGYr26E_yd1rBiq7DARF-PsKvr5UaT7OeQqJvRi=w1132-h699-no"
 
def metallica(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLV3gsrv9fnV8TyApiRVN3LrE4eptk9n0L3NXJDUeKdqTVj06qjTKKTwRbwY6KueSy1g50ZJDumGKk5BOOCR2rT9puNVMQahEud1YeVfwRMomy5L65HqyBMcL5aP84P9BrQeXv11XS7KyZJZF3wXDoSR=w1350-h759-no"

def full_concerts(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLWFYOevR7LnqL7yO5ZNxhseigENz3xtaFXE_WJRERXYWEA4aZFvigz7dqbgw47iJApOvSonSTTAoNQ6IgvR6ZpkNZwtIpJOrW7Xxa1MtFuXjTF8M00ff892_MbNB108V-kU_qcsHHCuQmRbIklgWWf3=w1000-h677-no"

def megadeth3(params):
    return "https://lh3.googleusercontent.com/pw/AL9nZEWByX7-o0JzByF3XRnWSZxLAGpYsiO3THsw5fiezoMjeicsuhKYkluM8N-ef9wGB4sZXdSb-IpzmCEzLN2NA3YjYpEnR_TsNGHR3OR_gb3zhWZZM9TSjX5DinmN5ZahF_Z41eF2s8-_lwdTMc960U4Q=w1080-h720-no"
    
def crisix(params):
    return "https://lh3.googleusercontent.com/pw/AP1GczPDALKDSZR6jKFU0__XfZuEkGOllTNXhihk43OoDlbj9UqPgfsWVO8_wkXlA_Cs-9Jo3hkFQIUO8Lt6Waf5ZZPNhuNNhIk8EJg-bA96dCg-i43ybJhnF52kQMPV0f2R8w_LNkh_7_R5Kik8IL-RFah9=w463-h133-s-no"
    
