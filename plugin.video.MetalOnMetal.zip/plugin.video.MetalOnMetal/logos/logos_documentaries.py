def documentaries(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3ewWRgvKtJDMT_c2Kwl5gRuqG2PFRja4ZTltPqHxWCwpfU0sCJ0AIj_i3H4gc8N1Lc6-NnvJT79fPBpJ7OaGsUFGscKUf1DmosH-8IFq4vAGyBpFAW94AJd2zR-D_3oyrd5Xg1XnLjQzYdWt8na6dVF=w919-h950-no"
    
def gibsontv(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3fLG6ZfQ1yiq7uNobPHrinSogXqYGUii-29_g5WecDCPiA6J1ocLj_SC8neWQSdzrFEJ4all-P0qIzDsExOYiq67xs3OoNWbCcD8sd1-QyNHKcd_pd7D9HDhIT_pKrrM_rRtZl_G8YHL_NCThw3u2eh=s900-no"
  
