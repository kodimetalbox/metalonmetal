import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

##id_WACKEN_2020 = "PLnTZcLO8ghQdmJ6fTc8unoK0haaMefDF-"
id_W3_SONGS = "PLnTZcLO8ghQdmQXP59m2hBQ2WMqfXHn_K"
id_ALL_LIVE_SHOWS = "PLPfPNs01OQC3pLnvPFudbDoBEReM3xcRw"
id_BEST_FULL_SHOWS = "PLnTZcLO8ghQcv2Pa4FosEVeEDIJ2a6C5U"
id_BLACK_METAL_BANDS = "PLPfPNs01OQC0_wDTyJ_UWJKZOvBdN4fXt"
id_DEATH_METAL_BANDS = "PLPfPNs01OQC1vKSeAX1xa7vfe3l1BD3Ks"
id_GRINDCORE_EXTREME_METAL_BANDS = "PLPfPNs01OQC2KEypK4oYX9_pNuVMamUVI"
id_HEAVY_ROCK_BANDS = "PLPfPNs01OQC3ET6JyUgbW6R5Yp8BReNFd"
id_MEDIAVAL_METAL_BANDS = "PLPfPNs01OQC2iNfBOXBwUpy1XWnRSJuYv"
id_MELODIC_DEATH_METAL_BANDS = "PLPfPNs01OQC2-vQ9ORH8LHgkTa36odnBu"
id_METAL_ICONS = "PLPfPNs01OQC2aXVVsXN4xDbM2Nx-tZVcl"
id_PAGAN_VIKING_METAL_BANDS = "PLPfPNs01OQC09sP2au8177_PpZag8e0jt"
id_ROCK_ICONS = "PLPfPNs01OQC3_H1e978hugznB6S7ItZ8Q"
id_SYMPHONIC_METAL_BANDS = "PLPfPNs01OQC001OWeN4j4o-UmdK7SBiwP"
id_THRASH_METAL_BANDS = "PLPfPNs01OQC1W-iGG0wy0Oo3W4ihaZZAi"
##
id_POWER_METAL_BANDS = "PLPfPNs01OQC1cp6O1jxo-bfWMG0-l_clJ"
id_FEMALE_FRONT_METAL_BANDS = "PLPfPNs01OQC3VGOonL-cJzGSOCPdJtvQf"
id_HARDCORE_PUNK_BANDS = "PLPfPNs01OQC0xUcdeFis9J2HHta5lqTc6"
id_PUNK_BANDS = "PLPfPNs01OQC2h5WB8zlm1XBxAdmSdzkS2"
id_PROGRESSIVE_METAL_BANDS = "PLPfPNs01OQC1FebN5K6N7GvI8ChfDApHL"
id_DARK_GOTHIC_INDUSTRIAL_BANDS ="PLPfPNs01OQC0Q9v9WwJt1zB2cJYVtBZrc"

if usa_duffyou:  ##Usamos plugin Duff You
    ##reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_WACKEN_2020)
    WACKEN_2020 = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
    W3_SONGS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_W3_SONGS).encode('utf-8')).decode('utf-8')
    ALL_LIVE_SHOWS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_ALL_LIVE_SHOWS).encode('utf-8')).decode('utf-8')
    BEST_FULL_SHOWS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_BEST_FULL_SHOWS).encode('utf-8')).decode('utf-8')
    BLACK_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_BLACK_METAL_BANDS).encode('utf-8')).decode('utf-8')
    DEATH_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_DEATH_METAL_BANDS).encode('utf-8')).decode('utf-8')
    GRINDCORE_EXTREME_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_GRINDCORE_EXTREME_METAL_BANDS).encode('utf-8')).decode('utf-8')
    HEAVY_ROCK_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_HEAVY_ROCK_BANDS).encode('utf-8')).decode('utf-8')
    MEDIAVAL_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_MEDIAVAL_METAL_BANDS).encode('utf-8')).decode('utf-8')
    MELODIC_DEATH_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_MELODIC_DEATH_METAL_BANDS).encode('utf-8')).decode('utf-8')
    METAL_ICONS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_METAL_ICONS).encode('utf-8')).decode('utf-8')
    PAGAN_VIKING_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_PAGAN_VIKING_METAL_BANDS).encode('utf-8')).decode('utf-8')
    ROCK_ICONS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_ROCK_ICONS).encode('utf-8')).decode('utf-8')
    SYMPHONIC_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_SYMPHONIC_METAL_BANDS).encode('utf-8')).decode('utf-8')
    THRASH_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_THRASH_METAL_BANDS).encode('utf-8')).decode('utf-8')
    POWER_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_POWER_METAL_BANDS).encode('utf-8')).decode('utf-8')
    FEMALE_FRONT_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_FEMALE_FRONT_METAL_BANDS).encode('utf-8')).decode('utf-8')
    HARDCORE_PUNK_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_HARDCORE_PUNK_BANDS).encode('utf-8')).decode('utf-8')
    PUNK_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_PUNK_BANDS).encode('utf-8')).decode('utf-8')
    PROGRESSIVE_METAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_PROGRESSIVE_METAL_BANDS).encode('utf-8')).decode('utf-8')
    DARK_GOTHIC_INDUSTRIAL_BANDS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_DARK_GOTHIC_INDUSTRIAL_BANDS).encode('utf-8')).decode('utf-8')
    # = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , ).encode('utf-8')).decode('utf-8')
else:  ##Usamos pluin YouTube
    ##WACKEN_2020 = youtube.replace("MI-ID-PLAYLIST" , id_WACKEN_2020)
    W3_SONGS =  youtube.replace("MI-ID-PLAYLIST" , id_W3_SONGS)
    ALL_LIVE_SHOWS =  youtube.replace("MI-ID-PLAYLIST" , id_ALL_LIVE_SHOWS)
    BEST_FULL_SHOWS =  youtube.replace("MI-ID-PLAYLIST" , id_BEST_FULL_SHOWS)
    BLACK_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_BLACK_METAL_BANDS)
    DEATH_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_DEATH_METAL_BANDS)
    GRINDCORE_EXTREME_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_GRINDCORE_EXTREME_METAL_BANDS)
    HEAVY_ROCK_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_HEAVY_ROCK_BANDS)
    MEDIAVAL_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_MEDIAVAL_METAL_BANDS)
    MELODIC_DEATH_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_MELODIC_DEATH_METAL_BANDS)
    METAL_ICONS =  youtube.replace("MI-ID-PLAYLIST" , id_METAL_ICONS)
    PAGAN_VIKING_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_PAGAN_VIKING_METAL_BANDS)
    ROCK_ICONS =  youtube.replace("MI-ID-PLAYLIST" , id_ROCK_ICONS)
    SYMPHONIC_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_SYMPHONIC_METAL_BANDS)
    THRASH_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_THRASH_METAL_BANDS)
    POWER_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_POWER_METAL_BANDS)
    FEMALE_FRONT_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_FEMALE_FRONT_METAL_BANDS)
    HARDCORE_PUNK_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_HARDCORE_PUNK_BANDS)
    PUNK_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_PUNK_BANDS)
    PROGRESSIVE_METAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_PROGRESSIVE_METAL_BANDS)
    DARK_GOTHIC_INDUSTRIAL_BANDS =  youtube.replace("MI-ID-PLAYLIST" , id_DARK_GOTHIC_INDUSTRIAL_BANDS)
    # =  youtube.replace("MI-ID-PLAYLIST" , )



def playlists(params):
    logo=logos_festivals.wacken(params)
    '''      
    plugintools.add_item( 
        #action="", 
        title="Wacken World Wide 2020",
        url=WACKEN_2020,
        thumbnail=logo, folder=True ) 
    '''
    plugintools.add_item( 
        #action="", 
        title="Wacken Best Full Shows",
        url=BEST_FULL_SHOWS,
        thumbnail=logo, folder=True )         


    plugintools.add_item( 
        #action="", 
        title="Wacken All Live Shows",
        url=ALL_LIVE_SHOWS,
        thumbnail=logo, folder=True ) 		

    plugintools.add_item( 
        #action="", 
        title="Wacken - 3 Songs",
        url=W3_SONGS,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Rock Icons",
        url=ROCK_ICONS,
        thumbnail=logo, folder=True )         
 
    plugintools.add_item( 
        #action="", 
        title="Metal Icons",
        url=METAL_ICONS,
        thumbnail=logo, folder=True )         

    plugintools.add_item( 
        #action="", 
        title="Heavy Rock Bands",
        url=HEAVY_ROCK_BANDS,
        thumbnail=logo, folder=True )         
     
    plugintools.add_item(  
        title="Power Metal Bands",
        url=POWER_METAL_BANDS,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Thrash Metal Bands",
        url=THRASH_METAL_BANDS,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Symphonic Metal Bands",
        url=SYMPHONIC_METAL_BANDS,
        thumbnail=logo, folder=True ) 
             
    plugintools.add_item(  
        title="Female Front Metal Bands",
        url=FEMALE_FRONT_METAL_BANDS,
        thumbnail=logo, folder=True ) 
             
    plugintools.add_item(  
        title="Progressive Metal Bands",
        url=PROGRESSIVE_METAL_BANDS,
        thumbnail=logo, folder=True )  
                
    plugintools.add_item( 
        #action="", 
        title="Death Metal Bands",
        url=DEATH_METAL_BANDS,
        thumbnail=logo, folder=True ) 		

    plugintools.add_item( 
        #action="", 
        title="Melodic Death Metal Bands",
        url=MELODIC_DEATH_METAL_BANDS,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Black Metal Bands",
        url=BLACK_METAL_BANDS,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Grindcore and Extreme Metal Bands",
        url=GRINDCORE_EXTREME_METAL_BANDS,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Pagan and Viking Metal Bands",
        url=PAGAN_VIKING_METAL_BANDS,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Mediaval Metal Bands",
        url=MEDIAVAL_METAL_BANDS,
        thumbnail=logo,
        folder=True )
             
    plugintools.add_item(  
        title="Dark Gothic Industrial Bands",
        url=DARK_GOTHIC_INDUSTRIAL_BANDS,
        thumbnail=logo, folder=True ) 
             
    plugintools.add_item(  
        title="Hardcore Punk Bands",
        url=HARDCORE_PUNK_BANDS,
        thumbnail=logo, folder=True ) 
              
    plugintools.add_item(  
        title="Punks Bands",
        url=PUNK_BANDS,
        thumbnail=logo, folder=True )  


