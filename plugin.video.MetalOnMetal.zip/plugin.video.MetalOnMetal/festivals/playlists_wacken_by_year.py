import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Wacken 2024", "PLnTZcLO8ghQeQqUJreA5yfd_CKEKIVjRU" ],
            [ "Wacken 2023", "PLnTZcLO8ghQfsTT_WsUBWzegQ59-BH4Jg" ],
            [ "Wacken 2022", "" ],
            [ "Wacken 2020", "" ],
            [ "Wacken 2019", "PLnTZcLO8ghQc6Sz-H1MiGEwAjntHpdgo0" ],
            [ "Wacken 2018", "" ],
            [ "Wacken 2017", "" ],
            [ "Wacken 2016", "" ],
            [ "Wacken 2015", "" ],
            [ "Wacken 2014", "" ],
            [ "Wacken 2013", "" ],
            [ "Wacken 2012", "PLnTZcLO8ghQdvpflCNhlkETym9GHgD798" ],
            [ "Wacken 2011", "" ],
            [ "Wacken 2009", "" ],
            [ "Wacken 2008", "" ],
            
            [ "Wacken 2007", "PLnTZcLO8ghQd__NY1EpOFNP6W4SlR5G5s" ],
            [ "Wacken 2006", "PLnTZcLO8ghQfuDS3rngjz0_A1XX77QAiw" ],
            [ "Wacken 2002", "PLnTZcLO8ghQelVMzWEFGAoQCNkQYOk7ON" ],
            [ "Wacken 2001", "" ],
            [ "Wacken 1999", "PLnTZcLO8ghQfto_4MylxrivLy5E3-d82B" ],
            [ "Wacken 1998", "PLnTZcLO8ghQeF27SyQJTQpWKy_5HF8tPx" ]])

def playlists(params):
    logo=logos_festivals.wacken(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





