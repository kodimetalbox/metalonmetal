import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

id_YEAR_2010 = "PLGuhlLazJwGvUPrfTK1Pif0Lbl2KLAcJu" 
id_YEAR_2011 = "PLGuhlLazJwGu3VSpYYQZIdGQZ52Hue016" 
id_YEAR_2012 = "PLGuhlLazJwGu70qzFhjvIioqSYHBscElN" 
id_YEAR_2013 = "PLGuhlLazJwGut5Ug_NjXmbHcBVqepdaNl" 
id_YEAR_2014 = "PLGuhlLazJwGt2GRHWVpWKrG_dYRzbXqYL" 
id_YEAR_2015 = "PLGuhlLazJwGunqDi6b3uUDAhyUlre_ZA-" 
id_YEAR_2016 = "PLGuhlLazJwGvucvnCyQXvVFeT4B2K6xhZ" 
id_YEAR_2017 = "PLGuhlLazJwGv8ITfSrSNCYmLUMBEcy8Ts" 
id_YEAR_2018 = "PLGuhlLazJwGv7VWjTOHy6UiMm3rxv-xdV" 
id_YEAR_2019 = "PLGuhlLazJwGsCTTkHaSPFz-7x2ik4-2Gv" 

if usa_duffyou:  ##Usamos plugin Duff You
    YEAR_2010 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2010).encode('utf-8')).decode('utf-8')
    YEAR_2011 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2011).encode('utf-8')).decode('utf-8')
    YEAR_2012 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2012).encode('utf-8')).decode('utf-8')
    YEAR_2013 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2013).encode('utf-8')).decode('utf-8')
    YEAR_2014 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2014).encode('utf-8')).decode('utf-8')
    YEAR_2015 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2015).encode('utf-8')).decode('utf-8')
    YEAR_2016 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2016).encode('utf-8')).decode('utf-8')
    YEAR_2017 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2017).encode('utf-8')).decode('utf-8')
    YEAR_2018 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2018).encode('utf-8')).decode('utf-8')
    YEAR_2019 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2019).encode('utf-8')).decode('utf-8')
    
    # = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_).encode('utf-8')).decode('utf-8')

else:  ##Usamos pluin YouTube
	YEAR_2010 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2010)
	YEAR_2011 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2011)
	YEAR_2012 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2012)
	YEAR_2013 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2013)
	YEAR_2014 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2014)
	YEAR_2015 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2015)
	YEAR_2016 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2016)
	YEAR_2017 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2017)
	YEAR_2018 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2018)
	YEAR_2019 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2019)

    # =  youtube.replace("MI-ID-PLAYLIST" , id_)


def playlists(params):
    logo=logos_festivals.rock_hard_festival(params)
    
    plugintools.add_item( 
        title="Hard Rock Festival 2019",
        url=YEAR_2019,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="Hard Rock Festival 2018",
        url=YEAR_2018,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="Hard Rock Festival 2017",
        url=YEAR_2017,
        thumbnail=logo, folder=True )

 
    plugintools.add_item( 
        title="Hard Rock Festival 2016",
        url=YEAR_2016,
        thumbnail=logo, folder=True )


    plugintools.add_item( 
        title="Hard Rock Festival 2015",
        url=YEAR_2015,
        thumbnail=logo, folder=True )

 
    plugintools.add_item( 
        title="Hard Rock Festival 2014",
        url=YEAR_2014,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="Hard Rock Festival 2013",
        url=YEAR_2013,
        thumbnail=logo, folder=True )


    plugintools.add_item( 
        title="Hard Rock Festival 2012",
        url=YEAR_2012,
        thumbnail=logo, folder=True )      

    plugintools.add_item( 
        title="Hard Rock Festival 2011",
        url=YEAR_2011,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="Hard Rock Festival 2010",
        url=YEAR_2010,
        thumbnail=logo, folder=True )

