import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
			[ "2024",  "PLnTZcLO8ghQdsNmcklsaDsJ-1sChf5Zed"],
			[ "2023",  "PLnTZcLO8ghQfF1Uz_YJ87AycwJF5dEUad"],
			[ "2022",  "PLnTZcLO8ghQedJnwAsY0S3awz5wJmSNNK"],
            [ "2019",  "PLnTZcLO8ghQfchn0yx35LZ1Dc9wzQPZJS"],
            [ "2018",  "PLnTZcLO8ghQfvGqv8wo2ygrkc0gXXGL7J"],
            [ "2017",  "PLnTZcLO8ghQd3CTvDD8_XNkTVft5xvf0F"],
            [ "2014",  "PLnTZcLO8ghQchilcnGwnzIJnGSceEsFPL"],
            [ "2012",  "PLnTZcLO8ghQd1hlR30Ih_9c51uN5gMeIY"],
            [ "2011",  "PLnTZcLO8ghQeCDhlK4CLZyMkgPmxTHChe"],
            [ "2009",   "PLnTZcLO8ghQfvnGJRExdKHsuR94EYDMiq"],
            [ "2008",  "PLnTZcLO8ghQekMdeLFdG0RpmHFuFwJbsU"],
            [ "2007",  "PLnTZcLO8ghQfsCSFflQdMtYQZrncoTT3y"],
            [ "2005",  "PLnTZcLO8ghQdnwgv5VywcKopH7_-pTkNw"],
            [ "2004",  "PLnTZcLO8ghQfgeySezpYGwRIQc4MC0ana"],
            [ "2002",  "PLnTZcLO8ghQdPb5Yc0iwmJt7a88XUdM1m"]])

def playlists(params):
    logo=logos_festivals.bloodstock(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

