import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


id_ARTE_CONCERT = "PL66OD4JjS_2PQTMDC3jP1iZJx30dG2Eia"
id_BEST_FULL_SHOWS = "PLGuhlLazJwGuo96p2C832lP5SQyZPQGAM"
id_YEAR_2011 = "PLxYfFQmDVUbMVptdIYRi8Ee-7X2Zpm7Vo"
id_YEAR_2012 = "PLxYfFQmDVUbNnptAyyX_DBXKqqIWHuklg"
id_YEAR_2015 = "PLxYfFQmDVUbOljFQLRHNsjqjyr0VrSaT3"
id_YEAR_2019 = "PLxYfFQmDVUbNn5zZoSRO4_x_qjwKu0uBa"
id_LIVE_SESSIONS_2021 = "PLxYfFQmDVUbOC5bX3l6PyXfp-zHQVXDJm"


if usa_duffyou:  ##Usamos plugin Duff You
    ARTE_CONCERT = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_ARTE_CONCERT).encode('utf-8')).decode('utf-8')
    BEST_FULL_SHOWS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_BEST_FULL_SHOWS).encode('utf-8')).decode('utf-8')
    YEAR_2011 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2011).encode('utf-8')).decode('utf-8')
    YEAR_2012 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2012).encode('utf-8')).decode('utf-8')
    YEAR_2015 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2015).encode('utf-8')).decode('utf-8')
    YEAR_2019 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2019).encode('utf-8')).decode('utf-8')
    LIVE_SESSIONS_2021= "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_LIVE_SESSIONS_2021).encode('utf-8')).decode('utf-8')
    
    # = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_).encode('utf-8')).decode('utf-8')

else:  ##Usamos pluin YouTube
	ARTE_CONCERT =  youtube.replace("MI-ID-PLAYLIST" , id_ARTE_CONCERT)
	BEST_FULL_SHOWS =  youtube.replace("MI-ID-PLAYLIST" , id_BEST_FULL_SHOWS)
	YEAR_2011 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2011)
	YEAR_2012 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2012)
	YEAR_2015 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2015)
	YEAR_2019 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2019)
	LIVE_SESSIONS_2021=  youtube.replace("MI-ID-PLAYLIST" , id_LIVE_SESSIONS_2021)
	
    # =  youtube.replace("MI-ID-PLAYLIST" , id_)


def playlists(params):
    logo=logos_festivals.hellfest(params)
    
    plugintools.add_item( 
        title="Best Full Shows",
        url=BEST_FULL_SHOWS,
        thumbnail=logo, folder=True ) 
       

       
    plugintools.add_item( 
        title="Live Sessions 2021",
        url=LIVE_SESSIONS_2021,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Hellfest 2019",
        url=YEAR_2019,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Hellfest 2015",
        url=YEAR_2015,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Hellfest 2012",
        url=YEAR_2012,
        thumbnail=logo, folder=True )      

    plugintools.add_item( 
        title="Hellfest 2011",
        url=YEAR_2011,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Arte Concert",
        url=ARTE_CONCERT,
        thumbnail=logo, folder=True ) 
