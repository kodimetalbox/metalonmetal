import plugintools
from logos import logos_documentaries
ICONS  = "plugin://plugin.video.youtube/playlist/PL7qLGYJiRJ1hr5qFhq3xFlyNNO1iQPjQU/"

def gibsontv1(params):
    logo=logos_documentaries.gibsontv(params)

    plugintools.add_item( 
        title="Icons",
        url=ICONS,
        thumbnail=logo, folder=True )  
       


