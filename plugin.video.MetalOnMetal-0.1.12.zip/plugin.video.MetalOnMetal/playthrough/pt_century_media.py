# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_guitar

L1 = "plugin://plugin.video.youtube/playlist/PL84FEBB669200C262/"



def function(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="Tutorials/Playthroughs from Century Media Records' Artists",
        url=L1,
        thumbnail=logo, folder=True )  


