# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon, xbmcgui

try:
    from urllib import urlretrieve
except:
    from urllib.request import urlretrieve
try:
    from xbmc import translatePath
except:
    from xbmcvfs import translatePath

from logos import logos_guitar

##  injector ,...
## https://www.youtube.com/channel/UCup-VDZk0978eCFEwwlyTIQ
## barricada
## red soil



addonID = 'plugin.video.MetalOnMetal'

local = xbmcaddon.Addon(id=addonID)

xbmc.executebuiltin('Container.SetViewMode(500)')




### BANDS
def f_accept(params):
    from bands import accept
    accept.accept1(params)

def f_acdc(params):   
    from bands import acdc
    acdc.acdc1(params)          

def f_amorphis(params):
    from bands import amorphis
    amorphis.amorphis1(params)          

def f_angelus(params):
    from bands import angelusapatrida
    angelusapatrida.angelusapatrida1(params)          
            
def f_anthrax(params):
    from bands import anthrax
    anthrax.anthrax1(params)   
       
def f_evile(params):
    from bands import evile
    evile.evile1(params) 

def f_powertrip(params):
    from bands import powertrip
    powertrip.powertrip1(params) 
    
   
def f_somascure(params):
    from bands import somascure
    somascure.somascure1(params) 
    
def f_stravaganzza(params):
    from bands import stravaganzza
    stravaganzza.stravaganzza1(params) 
         
def f_terravore(params):
    from bands import terravore
    terravore.terravore1(params)           
     
def f_the_wizards(params):
    from bands import the_wizards
    the_wizards.the_wizards1(params) 
    
### FESTIVALS
def f_wacken(params):
    from festivals import wacken
    wacken.wacken1(params) 

def f_hellfest(params):
    from festivals import hellfest
    hellfest.hellfest1(params) 

def f_resurrection(params):
    from festivals import resurrection
    resurrection.resurrection1(params) 


def f_rock_hard_festival(params):
    from festivals import rock_hard_festival
    rock_hard_festival.rock_hard_festival1(params) 
       
### Record Labels   
def f_century(params):
    from record_labels import century
    century.century1(params) 

def f_napalm(params):
    from record_labels import napalm
    napalm.function(params) 
 
def f_nuclear_blast(params):
    from record_labels import nuclear_blast
    nuclear_blast.function(params) 

def f_earache(params):
    from record_labels import earache
    earache.function(params)         
                
### Specials Playlists   
def f_best(params):
    from special_playlists import best
    best.best1(params) 

def f_spanish(params):
    from special_playlists import spanish
    spanish.spanish1(params) 
    
### YouTubeChannels  
def f_shauntrack(params):
    from youtube_channels import shauntrack
    shauntrack.shauntrack1(params)
    
def f_amusia(params):
    from youtube_channels import amusia
    amusia.amusia1(params)


### Documentaries
def f_GibsonTV(params):
    from documentaries import GibsonTV
    GibsonTV.GibsonTV1(params)

def f_HeadBangersJourney(params):
    from documentaries import HeadBangersJourney
    HeadBangersJourney.HeadBangersJourney1(params)

def f_doc_nervosa(params):
    from documentaries import Nervosa_Perpetual_Chaos
    Nervosa_Perpetual_Chaos.Nervosa_Perpetual_Chaos1(params)
        
### Genres
def f_power(params):
    from genres import power
    power.power1(params)
    
def f_thrash(params):
    from genres import thrash
    thrash.thrash1(params)
    
def f_symphonic(params):
    from genres import symphonic
    symphonic.symphonic1(params)
    
### Full Albums
def f_album_power(params):
    from full_albums import power
    power.power1(params)
    
def f_album_thrash(params):
    from full_albums import thrash
    thrash.thrash1(params)   

### Playthrough    
def f_pt_nervosa(params):
    from playthrough import pt_nervosa
    pt_nervosa.pt_nervosa1(params)  
    
def pt_century_media(params):
    from playthrough import pt_century_media
    pt_century_media.function(params)  
        
### Big Concerts
def f_bigfour(params):
    from bigconcerts import bigfour
    bigfour.bigfour1(params) 
        
def f_worldwired(params):
    from bigconcerts import worldwired
    worldwired.worldwired1(params) 
    
def f_moscow(params):
    from bigconcerts import moscow
    moscow.moscow1(params)                
    
def f_combat_tour(params):
    from bigconcerts import combat_tour
    combat_tour.combat_tour1(params) 
    
def f_full_concerts(params):
    from bigconcerts import full_concerts
    full_concerts.full_concerts1(params) 
                                

 ###########################################################
 ################ BANDS ####################################
 ###########################################################
          
def bands(params):
    from logos import logos_bands

    ACCEPT=logos_bands.accept(params)
    ACDC=logos_bands.acdc(params)
    AMORPHIS=logos_bands.amorphis(params)
    ANGELUS=logos_bands.angelusapatrida(params)
    ANTHRAX=logos_bands.anthrax(params)
    EVILE=logos_bands.evile(params)
    POWERTRIP=logos_bands.powertrip(params)    
    SOMASCURE=logos_bands.somascure(params)
    STRAVAGANZZA=logos_bands.stravaganzza(params)
    THE_WIZARDS=logos_bands.the_wizards(params)

    #=logos_bands.(params)    
    
    TERRAVORE=logos_bands.terravore(params)
    plugintools.add_item(action="f_accept",title="Accept", thumbnail=ACCEPT, folder=True )  
    plugintools.add_item(action="f_acdc", title="AC/DC", thumbnail=ACDC, folder=True )  
    plugintools.add_item(action="f_amorphis", title="Amorphis", thumbnail=AMORPHIS, folder=True )  
    plugintools.add_item(action="f_angelus", title="Angelus Apatrida", thumbnail=ANGELUS, folder=True )  
    plugintools.add_item(action="f_anthrax", title="Anthrax", thumbnail=ANTHRAX, folder=True ) 
    plugintools.add_item(action="f_evile", title="Evile", thumbnail=EVILE, folder=True )  
    plugintools.add_item(action="f_powertrip", title="Power Trip", thumbnail=POWERTRIP, folder=True ) 
    plugintools.add_item(action="f_somascure", title="Somas Cure", thumbnail=SOMASCURE, folder=True )
    plugintools.add_item(action="f_stravaganzza", title="Stravaganzza", thumbnail=STRAVAGANZZA, folder=True )  
    plugintools.add_item(action="f_terravore", title="Terravore", thumbnail=TERRAVORE, folder=True ) 
    plugintools.add_item(action="f_the_wizards", title="The Wizards", thumbnail=THE_WIZARDS, folder=True ) 
    #plugintools.add_item(action="f_", title="", thumbnail=, folder=True )   


#def bandas(params):
#    from bands import menu
#    menu.menu1(params)


    
    #from logos import logos_bands
    #ACCEPT=logos_bands.accept(params)
    #ACDC=logos_bands.acdc(params)
    #plugintools.add_item(action="f_accept",title="Accept", thumbnail=ACCEPT, folder=True )  
    #plugintools.add_item(action="f_acdc", title="AC/DC", thumbnail=ACDC, folder=True )  
       
 ###########################################################
 ################ FESTIVALS ################################
 ###########################################################
 
def festivals(params):
    from logos import logos_festivals
    WACKEN=logos_festivals.wacken(params)
    HELLFEST=logos_festivals.hellfest(params)
    RESURRECTION=logos_festivals.resurrection(params)
    ROCK_HARD=logos_festivals.rock_hard_festival(params)
    plugintools.add_item(action="f_wacken",title="Wacken", thumbnail=WACKEN, folder=True )  
    plugintools.add_item(action="f_hellfest",title="Hellfest", thumbnail=HELLFEST, folder=True )  
    plugintools.add_item(action="f_resurrection",title="Resurrection Fest", thumbnail=RESURRECTION, folder=True )  
    plugintools.add_item(action="f_rock_hard_festival",title="Rock Hard Festival", thumbnail=ROCK_HARD, folder=True )  

 ###########################################################
 ################ RECORD LABELS ############################
 ###########################################################

def recordlabels(params):
    from logos import logos_labels
    CENTURY=logos_labels.century(params)
    NAPALM=logos_labels.napalm2(params)
    NUCLEAR_BLAST=logos_labels.nuclear_blast(params)
    EARACHE=logos_labels.earache(params)
    plugintools.add_item(action="f_century",title="Century Media Records", thumbnail=CENTURY, folder=True )  
    plugintools.add_item(action="f_napalm",title="Napalm Records", thumbnail=NAPALM, folder=True )  
    plugintools.add_item(action="f_nuclear_blast",title="Nuclear Blast", thumbnail=NUCLEAR_BLAST, folder=True ) 
    plugintools.add_item(action="f_earache",title="Earache Records", thumbnail=EARACHE, folder=True )         
 ###########################################################
 ################ SPECIAL PLAYLISTS ########################
 ###########################################################
 
def specialplaylists(params):
    logo=logos_guitar.logo_04(params)
    plugintools.add_item(action="f_best",title="Best Metal Playlists", thumbnail=logo, folder=True )
    plugintools.add_item(action="f_spanish",title="Spanish Metal Playlists", thumbnail=logo, folder=True )  
      
 ###########################################################
 ################ YOUTUBE CHANNELS #########################
 ###########################################################
 
def youtubechannels(params):
    from logos import logos_youtube_channels
    SHAUNTRACK=logos_youtube_channels.shauntrack(params)
    plugintools.add_item(action="f_shauntrack",title="Shaun Track", thumbnail=SHAUNTRACK, folder=True )  
    AMUSIA=logos_youtube_channels.amusia(params)
    plugintools.add_item(action="f_amusia",title="El canal de Amusia", thumbnail=AMUSIA, folder=True )  
      
 ###########################################################
 ################ DOCUMENTARIES ############################
 ###########################################################
 
#def documentaries(params):
#    from logos import logos_documentaries
#    GIBSONTV=logos_documentaries.gibsontv(params)
#    ICONS  = "plugin://plugin.video.youtube/playlist/PL7qLGYJiRJ1hr5qFhq3xFlyNNO1iQPjQU/"
#    plugintools.add_item( 
#        title="Icons - Gibson TV",
#        url=ICONS,
#        thumbnail=GIBSONTV, folder=True )  
        
def documentaries(params):
    logo=logos_guitar.logo_06(params)
    plugintools.add_item(action="f_GibsonTV",title="Gibson TV", thumbnail=logo, folder=True )  
    plugintools.add_item(action="f_HeadBangersJourney",title="A Headbanger's Journey", thumbnail=logo, folder=True )  
    plugintools.add_item(action="f_doc_nervosa",title="Nervosa Perpetual Chaos", thumbnail=logo, folder=True )  
 
 ###########################################################
 ################ METAL GENRES #############################
 ###########################################################
 
def genres(params):
    logo=logos_guitar.logo_07(params)
    plugintools.add_item(action="f_power",title="Power", thumbnail=logo, folder=True )  
    plugintools.add_item(action="f_thrash",title="Thrash", thumbnail=logo, folder=True )       
    plugintools.add_item(action="f_symphonic",title="Symphonic", thumbnail=logo, folder=True )   

 ###########################################################
 ################ FULL ALBUMS ##############################
 ###########################################################
 
def full_albums(params):
    logo=logos_guitar.logo_08(params)
    plugintools.add_item(action="f_album_power",title="Power", thumbnail=logo, folder=True )  
    plugintools.add_item(action="f_album_thrash",title="Thrash", thumbnail=logo, folder=True ) 

 ###########################################################
 ################ Playthrough ##############################
 ###########################################################          
def playthrough(params):
    logo=logos_guitar.logo_09(params)
    plugintools.add_item(action="f_pt_nervosa",title="Nervosa", thumbnail=logo, folder=True )  
    plugintools.add_item(action="pt_century_media",title="Century Media Artits", thumbnail=logo, folder=True ) 
              
 ###########################################################
 ################ Big Concerts ##############################
 ###########################################################          
def big_concerts(params):
    from logos import logos_big_concerts
    logo=logos_guitar.logo_10(params)
    BIGFOUR=logos_big_concerts.bigfour(params) 
    MOSCOW=logos_big_concerts.moscow(params) 
    plugintools.add_item(action="f_bigfour",title="The Big Four", thumbnail=BIGFOUR, folder=True ) 
    plugintools.add_item(action="f_worldwired",title="On Tour with Metallica", thumbnail=logo, folder=True )             
    plugintools.add_item(action="f_moscow",title="Moscow Music Peace Festival", thumbnail=MOSCOW, folder=True )     
    plugintools.add_item(action="f_combat_tour",title="Combat Tour", thumbnail=logo, folder=True )   
    plugintools.add_item(action="f_full_concerts",title="Full Concerts", thumbnail=logo, folder=True )    
          
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()
    
    
class Updater:
    def __init__(self):
        import xml.etree.ElementTree as ET
        self.current_version = local.getAddonInfo("version")
        self.source = "https://kodimetalbox.github.io/metalonmetal/"
        self.data = plugintools.read(self.source)
        self.tree = ET.fromstring(self.data)
        self.parse = self.tree.findall('body')[0]
        self.href = (self.parse.findall('a')[0].get('href'))
        self.remote_version = self.href.split('-')[1].split(".zip")[0]
    def check(self):
        if self.current_version >= self.remote_version: 
            #xbmcgui.Dialog().notification( local.getAddonInfo("name") , "[COLOR limegreen]Versión correcta[/COLOR]" )
            #xbmcgui.Dialog().notification( local.getAddonInfo("name") , "Versión correcta" )
            return True
        else:
            urlretrieve(self.source + self.href, os.path.join(plugintools.get_runtime_path(), self.href))
            from zipfile import ZipFile
            dir = ZipFile ( os.path.join(plugintools.get_runtime_path(), self.href) , 'r' )
            dir . extractall ( translatePath(os.path.join('special://home/addons','')))
            dir . close ( )
            os.remove(os.path.join(plugintools.get_runtime_path(), self.href))
            xbmcgui.Dialog().notification( local.getAddonInfo("name") , "[COLOR limegreen]Addon actualizado, apaga Kodi y vuelve a entrar.[/COLOR]" )
            xbmcgui.Dialog().notification( local.getAddonInfo("name") , "Addon actualizado, apaga Kodi y vuelve a entrar." )
            xbmcgui.Dialog().notification( local.getAddonInfo("name") , "[COLOR limegreen]Apaga Kodi y vuelve a entrar.[/COLOR]" )
            return False
            
                
####### Añadir:  documentales 
# Main menu
def main_list(params):
    if Updater().check()==True:
        logo_01=logos_guitar.logo_01(params)
        logo_02=logos_guitar.logo_02(params)
        logo_03=logos_guitar.logo_03(params)
        logo_04=logos_guitar.logo_04(params)
        logo_05=logos_guitar.logo_05(params)
        logo_06=logos_guitar.logo_06(params)
        logo_07=logos_guitar.logo_07(params)
        logo_08=logos_guitar.logo_08(params)
        logo_09=logos_guitar.logo_09(params)
        logo_10=logos_guitar.logo_10(params)
        logo_11=logos_guitar.logo_11(params)
        logo_12=logos_guitar.logo_12(params)
        logo_13=logos_guitar.logo_13(params)
        
        plugintools.log("docu.main_list "+repr(params))

        plugintools.add_item( 
            action="bands", 
            title="Bands",
            thumbnail=logo_01,
            folder=True )  

#        plugintools.add_item( 
#            action="bandas", 
#            title="Bandas",
#            thumbnail=logo_01,
#            folder=True ) 
        
                        
        plugintools.add_item( 
            action="festivals", 
            title="Festivals",
            thumbnail=logo_02,
            folder=True ) 

        plugintools.add_item( 
            action="big_concerts", 
            title="Big Concerts",
            thumbnail=logo_10,
            folder=True )    
            
        plugintools.add_item( 
            action="recordlabels", 
            title="Record Labels",
            thumbnail=logo_03,
            folder=True ) 

        plugintools.add_item( 
            action="specialplaylists", 
            #action="recordlabels",
            title="Special Playlists",
            thumbnail=logo_04,
            folder=True ) 
            
        plugintools.add_item( 
            action="youtubechannels", 
            title="YouTube Channels",
            thumbnail=logo_05,
            folder=True )
            

        plugintools.add_item( 
            action="documentaries", 
            title="Documentaries",
            thumbnail=logo_06,
            folder=True )
            

            
        plugintools.add_item( 
            action="genres", 
            title="Videos by Metal Genres",
            thumbnail=logo_07,
            folder=True )
            
            
            
        plugintools.add_item( 
            action="full_albums", 
            title="Full Albums",
            thumbnail=logo_08,
            folder=True )

        plugintools.add_item( 
            action="playthrough", 
            title="Playthrough",
            thumbnail=logo_09,
            folder=True )            
            

run()
