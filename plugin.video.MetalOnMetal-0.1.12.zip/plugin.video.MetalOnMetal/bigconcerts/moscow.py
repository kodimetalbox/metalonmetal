# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_big_concerts

N1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGsNrlDby1YpjW_RpFp-YY41/"



def moscow1(params):
    logo=logos_big_concerts.moscow(params) 
    
    plugintools.add_item( 
        title="Full Concerts",
        url=N1,
        thumbnail=logo, folder=True )  



