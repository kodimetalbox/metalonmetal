# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_guitar



N1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGtSMEwdNagCzEMKZusRiSaD/"



def combat_tour1(params):
    logo=logos_guitar.logo_10(params)
    
    plugintools.add_item( 
        title="Combat Tour",
        url=N1,
        thumbnail=logo, folder=True ) 
    

