# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_guitar



N1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuLED6lwpyrz1Qigq2K4ysf/"
N2 = "plugin://plugin.video.youtube/playlist/PLJvQXRgtxluml0XI5bcvTTzsxE9b7hrWC/"
N3 = "plugin://plugin.video.youtube/playlist/PLJvQXRgtxluml0XI5bcvTTzsxE9b7hrWC/"
N4 = "plugin://plugin.video.youtube/playlist/PLJvQXRgtxlukIkmzucaV3rSFgYYdTr85A/"

def worldwired1(params):
    logo=logos_guitar.logo_10(params)
    
    plugintools.add_item( 
        title="#MetallicaModays",
        url=N4,
        thumbnail=logo, folder=True ) 
    
    plugintools.add_item( 
        title="Metallica - Concerts WorldWired Tour",
        url=N1,
        thumbnail=logo, folder=True )  


    plugintools.add_item( 
        title="Metallica - Videos WorldWired Tour",
        url=N2,
        thumbnail=logo, folder=True ) 
        
    plugintools.add_item( 
        title="Metallica - Videos WorldWired Euopean Tour",
        url=N3,
        thumbnail=logo, folder=True )  
 

