# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_guitar

ICONS = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGtKgAPehN4C9qPG5E2lc0oX/"



def HeadBangersJourney1(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="A HeadBanger's Journey",
        url=ICONS,
        thumbnail=logo, folder=True )  


