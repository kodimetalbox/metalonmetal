import plugintools

from logos import logos_guitar

DOC1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuthyCs1E4uu3h2dIpN7yKr/"
DOC2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGtBM5CJX23yDPrGckgwljBa/"


def extremoduro_doc(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="History",
        url=DOC1,
        thumbnail=logo, folder=True )  
    
    plugintools.add_item( 
        title="Other documents",
        url=DOC2,
        thumbnail=logo, folder=True )  

