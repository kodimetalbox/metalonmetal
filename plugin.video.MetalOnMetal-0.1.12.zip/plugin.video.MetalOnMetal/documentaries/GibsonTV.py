import plugintools

from logos import logos_guitar

ICONS = "plugin://plugin.video.youtube/playlist/PL7qLGYJiRJ1hr5qFhq3xFlyNNO1iQPjQU/"



def GibsonTV1(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="Icons - Gibson TV",
        url=ICONS,
        thumbnail=logo, folder=True )  


