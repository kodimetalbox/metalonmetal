import plugintools

from logos import logos_guitar

DOC = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuzej_Lx3ouHeafgZAVgU9U/"



def Nervosa_Perpetual_Chaos1(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="Perpetual Chaos Album",
        url=DOC,
        thumbnail=logo, folder=True )  


