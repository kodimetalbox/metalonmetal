# -*- coding: utf-8 -*-
#------------------------------------------------------------
import plugintools
from logos import logos_bands


LISTA1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGtsKX6zN99kcGU1TaD4qVuj/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuUFI8gVxJh-URgY4boSQGm/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuNQM8htJmnpoEP8Dpun7y6/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g-1fegudHrQDznAaCm6S6AN/" 
LISTA5 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g_cZU7IgwG_MsNVDI1xQmay/" 
LISTA6 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g9TE0yjw3PXJlXRig9v_WpH/" 
LISTA7 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g815bYYPoF53ogLuI6SQO5N/" 
LISTA8 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g83KfERkJSMONE9vTeMWj9u/" 
LISTA9 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g_ljm8dBLIvOb_6qM077HRx/" 
LISTA10 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g_7e2i0nXgpomapbaW7KktE/" 
LISTA11 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g-28tq77qvPKKz7_bd5Davy/" 
LISTA12 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g99ag69HQxXakicGzKVLzjY/" 
LISTA13 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g-D9Q2ZVF9GXAI9VwkLrRrl/" 
LISTA14 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g8xafU_gWpid_M2rINbHhBD/" 
LISTA15 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g9AL6tSDoAE57GCfGH3qK4b/" 
LISTA16 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g_DQ0Me4IBNuB-vtkS3rNIu/" 
LISTA17 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g90q5PqwmEhPV1D1jeDi8Ek/" 
LISTA18 = "plugin://plugin.video.youtube/playlist/PLMcZL3jav3g8EnBw8C5RWc2uZ0kc3-LdC/" 
LISTA19 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGsD1j63jnjLO9Tx_f0_O47x/" 



def barricada1(params):
    logo=logos_bands.barricada(params)

    plugintools.add_item( 
        title="Videos",
        url=LISTA1,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="Live Shows",
        url=LISTA2,
        thumbnail=logo, folder=True )
       
    plugintools.add_item( 
        title="Concierto 1984 - III Fiesta del estudiante",
        url=LISTA13,
        thumbnail=logo, folder=True )               

    plugintools.add_item( 
        title="Conciertos de Radio 3 - 2000",
        url=LISTA15,
        thumbnail=logo, folder=True )
                              

    plugintools.add_item( 
        title="Concierto 2005 - Latidos",
        url=LISTA5,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Concierto Acústico 2006 - Mordiscos",
        url=LISTA6,
        thumbnail=logo, folder=True )
    
    plugintools.add_item( 
        title="Concierto 2009 - Otra noche sin dormir",
        url=LISTA7,
        thumbnail=logo, folder=True )


    plugintools.add_item( 
        title="Conciertos de Radio 3 - 2010",
        url=LISTA19,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Acústico 2012 - El vuelo del Fénix",
        url=LISTA9,
        thumbnail=logo, folder=True )


    plugintools.add_item( 
        title="Concierto 2014 - Agur",
        url=LISTA4,
        thumbnail=logo, folder=True )
               
        
    plugintools.add_item( 
        title="1986 - RTVE Tocata",
        url=LISTA14,
        thumbnail=logo, folder=True )
                               
    plugintools.add_item( 
        title="1988 - RTVE A Tope",
        url=LISTA10,
        thumbnail=logo, folder=True )

        
    plugintools.add_item( 
        title="1993 - Antena 3 Leña al mono que es de goma",
        url=LISTA12,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="2000 Euskadi Gaztea",
        url=LISTA16,
        thumbnail=logo, folder=True )
                                              
    plugintools.add_item( 
        title="2008 - RTVE No disparen al pianista",
        url=LISTA11,
        thumbnail=logo, folder=True )
      
    plugintools.add_item( 
        title="Maquetas - Contenido inédito",
        url=LISTA17,
        thumbnail=logo, folder=True )

        
    plugintools.add_item( 
        title="Maqueta 1995",
        url=LISTA8,
        thumbnail=logo, folder=True )
        
                              
    plugintools.add_item( 
        title="Documentaries",
        url=LISTA3,
        thumbnail=logo, folder=True )
        
               
    plugintools.add_item( 
        title="Alfredo Piedrafita - Monster Class",
        url=LISTA18,
        thumbnail=logo, folder=True )
         
