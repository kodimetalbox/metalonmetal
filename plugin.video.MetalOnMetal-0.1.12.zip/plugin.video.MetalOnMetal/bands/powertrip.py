import plugintools
from logos import logos_bands

CLIPS = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGsZyBHqnaP-5iF2NvLwJ-aB/"
LIVE = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGu12cIOPlZ_NnZaLvQsyY_6/"
 
NIGTHMARE = "plugin://plugin.video.youtube/playlist/PLwPBM4hpb3mPZHQcyqxaF9VH-r0rOvshs/"
MANIFEST = "plugin://plugin.video.youtube/playlist/PLLZUjlvnKF05riAZSU_5QiagRULPuwakm/"
OPENING = "plugin://plugin.video.youtube/playlist/PLxL_xqJBZ6zgRo3SUi4SOzEQ5qCDf8i3p/"


def powertrip1(params):
    logo=logos_bands.powertrip(params)
		
    plugintools.add_item( 
        title="Videos",
        url=CLIPS,
        thumbnail=logo, folder=True )
             
    plugintools.add_item( 
        title="Live Shows",
        url=LIVE,
        thumbnail=logo, folder=True )
             
    plugintools.add_item( 
        title="Power Trip | Nightmare Logic (Full Album)",
        url=NIGTHMARE,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Power Trip | Manifest Decimation (Full Album)",
        url=MANIFEST,
        thumbnail=logo, folder=True )   

        
    plugintools.add_item( 
        title="Power Trip |  Opening Fire (Full Album)",
        url=OPENING,
        thumbnail=logo, folder=True )   

