# -*- coding: utf-8 -*-
#------------------------------------------------------------
import plugintools
from logos import logos_bands


LISTA1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvRAbE_sYi-vAkEPpdeQbxD/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLwdURkEmqwCHQkSMtTn03M_R50AigTDeh/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLdtAahlfc_S1nQ7MN3pw6t2tw_aRQlUr3/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PL72A1F4DFA233540D/" 
LISTA5 = "plugin://plugin.video.youtube/playlist/PLdJ5Kn2xL-Qsj0zLxTE96uAQopk6sCy5F/" 
LISTA6 = "plugin://plugin.video.youtube/playlist/PLmrXqVV2AtiNYuSeRDxr43-iPvRw4mG60/"
LISTA7 = "plugin://plugin.video.youtube/playlist/PLdtAahlfc_S1H1bYlUCnErrnl7CrnVhRx/" 
 
def katatonia1(params):
    logo=logos_bands.katatonia(params)

    plugintools.add_item( 
        title="Live Shows",
        url=LISTA1,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="Sanctitude - Full Concert",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Official Videos",
        url=LISTA3,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Morer Official Videos",
        url=LISTA4,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Unofficial Musicvideo´s Playlist",
        url=LISTA5,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="The Best Of Katatonia",
        url=LISTA6,
        thumbnail=logo, folder=True )
                
    plugintools.add_item( 
        title="City Burials Album",
        url=LISTA7,
        thumbnail=logo, folder=True )
               

