# -*- coding: utf-8 -*-
#------------------------------------------------------------
import plugintools
from logos import logos_bands


LISTA1 = "plugin://plugin.video.youtube/playlist/PLf7A5YJYUq0lRO8yswSD2MEN-bLdjmI_g/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGtbYmNIavzMUpOBSFloZM0s/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvg6837FBDdW69xWSAxUb8d/" 


def tierrasanta1(params):
    logo=logos_bands.tierrasanta(params)

    plugintools.add_item( 
        title="Official Videos",
        url=LISTA1,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="More Videos",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Live Shows",
        url=LISTA3,
        thumbnail=logo, folder=True )
        


