import plugintools
from logos import logos_bands

OFFICIAL = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5NkEBEVyWqIXFlLjViRxnfZ/"
ALL = "plugin://plugin.video.youtube/playlist/PL8nmR00A-vx0ydQeaWKn3wNJRbNZcvrCH/" 
LIVE = "plugin://plugin.video.youtube/playlist/PL769CE0F99D9F7ABE/" 
LIVE2 = "plugin://plugin.video.youtube/playlist/PL769CE0F99D9F7ABE/" 
REHEARSAL = "plugin://plugin.video.youtube/playlist/PL6038EEE0DA5C92EF/"

def evile1(params):
    logo=logos_bands.evile(params)
		
    plugintools.add_item( 
        title="Official Videos",
        url=OFFICIAL,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="All Evile Songs",
        url=ALL,
        thumbnail=logo, folder=True )   


             
    plugintools.add_item( 
        title="Mike Alexander Memorial Show: London, Dec '09",
        url=LIVE,
        thumbnail=logo, folder=True )
    
    plugintools.add_item( 
        title="Live Shows",
        url=LIVE2,
        thumbnail=logo, folder=True )



               
    plugintools.add_item( 
        title="Evile: Rehearsal Room",
        url=REHEARSAL,
        thumbnail=logo, folder=True )

