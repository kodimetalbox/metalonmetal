# -*- coding: utf-8 -*-
#------------------------------------------------------------
import plugintools
from logos import logos_bands





LISTA1 = "plugin://plugin.video.youtube/playlist/PL4A0jrfkoDjD9izjAjwi06AMQMHqg2i4Q/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PL3q3Rt60txN4MGbnkiNxOcV_x26_LjCyH/"  
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGv175uuDQqqh0kxmQcwRBpI/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PL1W7VJUBccXTFJUwsYojbp9ntgUdgFmhZ/" 
LISTA5 = "plugin://plugin.video.youtube/playlist/OLAK5uy_nRbd5iHoKKqEuRx8FicZxHF9uqWq4ajjk/" 
LISTA6 = "plugin://plugin.video.youtube/playlist/OLAK5uy_nScl-LUAlY9_OlmAPSW4W_W4EwxW57kM0/" 
LISTA7 = "plugin://plugin.video.youtube/playlist/OLAK5uy_lekgTjTLYFHIDqaDuZxP42KLcS3fiwgi4/" 
LISTA8 = "plugin://plugin.video.youtube/playlist/OLAK5uy_mplVwVvFqFmWw1Og8zDgcHbW8OX5BH56U/" 
LISTA9 = "plugin://plugin.video.youtube/playlist/OLAK5uy_ntbfM-HzcJU6uVAuT-up6wVnx-wF0EL-c/" 
LISTA10 = "plugin://plugin.video.youtube/playlist/OLAK5uy_mB4EFnIummZCiBUWsk_g_y2jdBdLjWJU4/" 
LISTA11= "plugin://plugin.video.youtube/playlist/PLBuhT8-dSGv8NM74jOjPhILozmcIILsyc/" 


def stravaganzza1(params):

    logo=logos_bands.stravaganzza(params)
    discography=logos_bands.discography(params)	

    plugintools.add_item( 
        title="Lo mejor de Stravaganzza - Avispa Music",
        url=LISTA1,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Mejores canciones",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Los conciertos de Radio3",
        url=LISTA3,
        thumbnail=logo, folder=True )  
                     
    plugintools.add_item( 
        title="Leo Jiménez: Concierto en Circo Volador, México D.F.",
        url=LISTA4,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Discography",
        thumbnail=discography, folder=False )
        
    plugintools.add_item( 
        title="Primer Acto (2004)",
        url=LISTA5,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Sentimientos - Segundo Acto (2005)",
        url=LISTA6,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Hijo del miedo - EP (2006)",
        url=LISTA7,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Réquiem - Tercer acto (2007)",
        url=LISTA8,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Raíces - Cuarto Acto (2010)",
        url=LISTA9,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="The Best Of... - Recopilatorio (2010)",
        url=LISTA10,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="La noche del fénix - Directo - (2020)",
        url=LISTA11,
        thumbnail=logo, folder=True )
               


