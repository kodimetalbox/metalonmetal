import plugintools
from logos import logos_bands

LIVE_SHOWS = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGsqskC5RY0qt8Pk0xclK14f/"
#LIVE_SHOWS = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGv175uuDQqqh0kxmQcwRBpI/"
OFFICIAL_VIDEOS = "plugin://plugin.video.youtube/playlist/PLF84630BDCCB15277/"
BEST_OF = "plugin://plugin.video.youtube/playlist/PLe7ia_jeVGd_vsqcTDyeeOHawvqoBFGbK/"
PROVA = "plugin://plugin.video.youtube/playlist/PLROk7uohWHPBg8XOfaOSUav9ZFIh7fPZG/"

def accept1(params):
    logo=logos_bands.accept(params)

    plugintools.add_item( 
        title="Live Shows",
        url=LIVE_SHOWS,
        thumbnail=logo,folder=True )
        
    plugintools.add_item( 
        title="Official Videos",
        url=OFFICIAL_VIDEOS,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Official Best of",
        url=BEST_OF,
        thumbnail=logo, folder=True )

       
    plugintools.add_item( 
        title="Prova",
        url=PROVA,
        thumbnail=logo, folder=True )


