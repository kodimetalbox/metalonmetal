import plugintools
#from logos import logos_bands

from logos import logos_labels


L1  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhxeUEXA2sj-J1kXQhon_3ER/"
L2  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhyhDBwaGcehI4nXfG_05Q-S/"
L3  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhxjhFZemPNDfdzmjTTQsgRn/"
L4  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhxU8YWXMgZnH7a2jJZoyBGD/"
L5  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhxB1DMxjTA0b9hUUY689xKG/"

L6  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhwtWkeHT1Onpkst_k0V6LTZ/"
L7  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhyL60IB_aMHRVM02z95zG6V/"
L8  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhznm5SOjGCt5wBIJMsPvr8P/"
L9  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhy-o6vbZxL8UrkuKT7L3rmP/"
L10  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhxD-ETO_LLUm6Jzi3AVZiSf/"

L11  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhybnEKS71J_sgH-FN0I3P74/"
L12  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhzZUft2kH0Iz0Cxp4W_Azrc/"
L13  = "plugin://plugin.video.youtube/playlist/PLidIjcybOMhxYKnhexQLC_WNdVatxpVDg/"
L14  = "plugin://plugin.video.youtube/playlist/PLlfqJred7Iwf80U5zNh_ED3QzSgF2oH1X/"

def function(params):
    logo=logos_labels.napalm2(params)

    plugintools.add_item( 
        title="Napalm Official Music Videos Playlist",
        url=L1,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Lyric Videos Playlist",
        url=L2,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="Live Videos Playlist",
        url=L3,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Heavy fucking Metal Playlist",
        url=L4,
        thumbnail=logo, folder=True )  
        
 
    plugintools.add_item( 
        title="Extreme Metal Playlist",
        url=L5,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Hardcore / Metalcore / Melodic Death Metal Playlist",
        url=L6,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="Female Fronted Metal Playlist",
        url=L7,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Symphonic & Power Metal Playlist",
        url=L8,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="Hard Rock Playlist",
        url=L9,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Rock, Stoner Rock and more... Playlist",
        url=L10,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="Medieval / Folk / Pagan Playlist",
        url=L11,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Full Concerts",
        url=L14,
        thumbnail=logo, folder=True )  
 
    plugintools.add_item( 
        title="Heavy Halloween Playlist",
        url=L12,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="Unboxing Videos Playlist",
        url=L13,
        thumbnail=logo, folder=True )  

