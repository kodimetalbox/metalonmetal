import plugintools
#from logos import logos_bands

from logos import logos_labels


L1  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P4zaBq7duea0Z9-wwFgMZUK/"
L2  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P7ZXJ0Qw9QayoLxHslFTzvF/"
L3  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P7IvKjXn7jOkJ4cCsF6bPd8/"
L4  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P4ocoTLNNB-tQEao4T5doxp/"
L5  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P6ZASQYEYp11EKSF3TYe6_c/"

L6  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P7aTZXCV5KLPITpP6J4upAG/"
L7  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P6OvedJkPV9SJdFUtIWaB1a/"
L8  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P5_yQzIZdlC7xsa3v0XAStE/"
L9  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P6jp764WUpP4Tor29yeI6Pt/"
L10  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P5RbZb1oe30-l2maOxOQZtX/"

L11  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P4cjJ5bEca_Nd7kUSbgteSW/"
L12  = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P6xIgHnat0STHkAzI0VJX5m/"

def function(params):
    logo=logos_labels.nuclear_blast(params)

    plugintools.add_item( 
        title="NUCLEAR BLAST - Official Music Videos",
        url=L1,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Nuclear Blast All Clips",
        url=L2,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="WELCOME TO THE PIT - Nuclear Blast Records LIVE!",
        url=L3,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="THRASH METAL / SPEED METAL - Nuclear Blast Records",
        url=L4,
        thumbnail=logo, folder=True )  
        
 
    plugintools.add_item( 
        title="MELODIC METAL / DEATH METAL - Nuclear Blast Records",
        url=L5,
        thumbnail=logo, folder=True )  

 
    plugintools.add_item( 
        title="POWER METAL / HEAVY METAL / SYMPHONIC METAL - Nuclear Blast Records",
        url=L6,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="HARD ROCK / HEAVY ROCK / ROCK - Nuclear Blast Records",
        url=L7,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="BLACK METAL / BLACKGAZE / POST-BLACK METAL - Nuclear Blast Records",
        url=L8,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="HARDCORE / METALCORE & BEYOND - Nuclear Blast Records",
        url=L9,
        thumbnail=logo, folder=True )  
        
 
    plugintools.add_item( 
        title="FOLK METAL / PAGAN METAL - Nuclear Blast Records",
        url=L10,
        thumbnail=logo, folder=True )  




    plugintools.add_item( 
        title="DOOM METAL / SLUDGE METAL / STONER ROCK - Nuclear Blast Records",
        url=L11,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Nuclear Blast Presents: Metal Fan Covers",
        url=L12,
        thumbnail=logo, folder=True )  
        
 
