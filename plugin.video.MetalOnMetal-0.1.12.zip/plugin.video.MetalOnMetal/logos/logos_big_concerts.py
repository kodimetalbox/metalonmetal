def bigfour(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3eYsJ9cevw97AH3sgMeAmm-gZ0iZSxSyiXJWorbXRlFu6BdKlHAk9BQKh0HfnAl6WLHiQXXSL_Wqqnd06NS71gjC0BoAsmjehSswzqNpIpZdzLJ_EFbkRZAQEs_91p4GDIPgtCOHz3tEWo9sW6nww8z=w386-h289-no"
   
def moscow(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3f7KAEYa8BWt8TetdrSihaFkktq3hTn4CmIKXrAvbYRTN66hXQV1Z_1hCdqYStD6z3ceAdzx7XQXbK945Sk9Jc3epuH9i0Ont6qmrwVioBZ8s_dJ9_1AQK1sLburQyR8axGGtLPcTp0uxYcaZAD3Sbi=w800-h693-no"
   

