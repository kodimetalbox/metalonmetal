def century(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3clPZFT7nQlDsB9aUCcC5QozWxgsrgHn09qDwiB47sxoQhAloOoBM64PJblGrvRoDTWegePDFLbqVIqCx-PrEGHmop2d_-aVrX67_zRSe2C5naTbwe2vNXW-Ye-cWEVZoWrkzlyybvY_IDZNDHxIkMJ=w797-h950-no"
   
def napalm(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dHH92FDNoPXWxEPSRcXcoZyIlLgnC91O1N32j4ICUNFb5spWIpmUXWe5s7qJ9Sp7GnZVUUh4Q9IEJjrLZD3sRCeGQrCo-gMEaRlIqT5S8DAKMTcO4FZqtrr-X7bBBJxSybntETAuNaXWsIv_pjoR-P=s512-no"
    
def napalm2(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3e_ngWBby3Zc5_jLhfdtiLVxN-XL4Z2pTXzndB5ToRDXsI8mHi4K1ntFuaH5ukQwpZWUN-HX8IKI6wikczCAzbv3cDeA2btowpBQUrRd904JBmzgxYiYXKYLT7IPF35R_d6mhJeEWij9NrmJtnRPeta=s300-no"
    
def nuclear_blast(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3ePHX936xIpa6VYaw6UXMJwxow-GZ6huLA3zXtt1gR0uXZ1nXUoNWeij0tOpjzBMoMdAOaY19WGsQ2HGuk7aCesiyPJ1YeB-I8vJD_wTRttJBPxa3Ugb3KGrBIoCHYuB0fAXw_LR9DOmgZd2N7AYkc=s768-no"
