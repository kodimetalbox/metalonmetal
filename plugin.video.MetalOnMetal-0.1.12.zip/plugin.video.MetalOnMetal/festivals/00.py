import plugintools
from logos import logos_festivals

LISTA1 = "plugin://plugin.video.youtube/playlist//" 
LISTA2 = "plugin://plugin.video.youtube/playlist//" 
LISTA3 = "plugin://plugin.video.youtube/playlist//" 
LISTA4 = "plugin://plugin.video.youtube/playlist//" 
LISTA5 = "plugin://plugin.video.youtube/playlist//" 
LISTA6 = "plugin://plugin.video.youtube/playlist//" 

def 1(params):
    logo=logos_festivals.(params)

    plugintools.add_item( 
        title="",
        url=LISTA1,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="",
        url=LISTA3,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="",
        url=LISTA4,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="",
        url=LISTA5,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="",
        url=LISTA6,
        thumbnail=logo, folder=True )
        
