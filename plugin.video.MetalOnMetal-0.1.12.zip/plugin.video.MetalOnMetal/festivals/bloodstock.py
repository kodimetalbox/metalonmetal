import plugintools
from logos import logos_festivals

LISTA1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGscQUF7aPIH4udG8ANOT8Ba/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuUAAk0mdCjsJEtD22SqyJx/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGulh732kXPR861-1CcP72IP/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGtNBchrXfcjsXFQnrvtu0-P/" 

 


def bloodstock1(params):
    logo=logos_festivals.bloodstock(params)

    plugintools.add_item( 
        title="Bloodstock Fest 2019",
        url=LISTA1,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="Bloodstock Fest 2018",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Bloodstock Fest 2017",
        url=LISTA3,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Bloodstock Fest 2016",
        url=LISTA4,
        thumbnail=logo, folder=True )
               

   
        

               
