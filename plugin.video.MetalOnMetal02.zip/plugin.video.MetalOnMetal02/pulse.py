# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
addonID = 'plugin.video.MetalOnMetal02'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)

xbmc.executebuiltin('Container.SetViewMode(500)')




YOUTUBE_CHANNEL_30_YEARS_OF_NUCLEAR_BLAST = "PLB4brr7vf-P4Sw27U1AsJvIevX5D7TQeW"

### BANDS
def f_accept(params):
    from bands import accept
    accept.accept1(params)

def f_acdc(params):   
    from bands import acdc
    acdc.acdc1(params)          

def f_amorphis(params):
    from bands import amorphis
    amorphis.amorphis1(params)          

def f_angelus(params):
    from bands import angelusapatrida
    angelusapatrida.angelusapatrida1(params)          
            
def f_anthrax(params):
    from bands import anthrax
    anthrax.anthrax1(params)      

def f_somascure(params):
    from bands import somascure
    somascure.somascure1(params) 
     
def f_terravore(params):
    from bands import terravore
    terravore.terravore1(params)           
### FESTIVALS

def f_wacken(params):
    from festivals import wacken
    wacken.wacken1(params) 

def f_hellfest(params):
    from festivals import hellfest
    hellfest.hellfest1(params) 

def f_resurrection(params):
    from festivals import resurrection
    resurrection.resurrection1(params) 

   
### Record Labels   
def f_century(params):
    from record_labels import century
    century.century1(params) 
    
### Specials Playlists   
def f_best(params):
    from special_playlists import best
    best.best1(params) 

def f_spanish(params):
    from special_playlists import spanish
    spanish.spanish1(params) 
    
### YouTubeChannels  
def f_shauntrack(params):
    from youtube_channels import shauntrack
    shauntrack.shauntrack1(params)
    
def f_amusia(params):
    from youtube_channels import amusia
    amusia.amusia1(params)


### Documentaries

### Genres
def f_power(params):
    from genres import power
    power.power1(params)
    
def f_thrash(params):
    from genres import thrash
    thrash.thrash1(params)

 ###########################################################
 ################ BANDS ####################################
 ###########################################################
          
def bands(params):
    from logos import logos_bands
    ACCEPT=logos_bands.accept(params)
    ACDC=logos_bands.acdc(params)
    AMORPHIS=logos_bands.amorphis(params)
    ANGELUS=logos_bands.angelusapatrida(params)
    ANTHRAX=logos_bands.anthrax(params)
    SOMASCURE=logos_bands.somascure(params)
    TERRAVORE=logos_bands.terravore(params)
    plugintools.add_item(action="f_accept",title="Accept", thumbnail=ACCEPT, folder=True )  
    plugintools.add_item(action="f_acdc", title="AC/DC", thumbnail=ACDC, folder=True )  
    plugintools.add_item(action="f_amorphis", title="Amorphis", thumbnail=AMORPHIS, folder=True )  
    plugintools.add_item(action="f_angelus", title="Angelus Apatrida", thumbnail=ANGELUS, folder=True )  
    plugintools.add_item(action="f_anthrax", title="Anthrax", thumbnail=ANTHRAX, folder=True )       
    plugintools.add_item(action="f_somascure", title="Somas Cure", thumbnail=SOMASCURE, folder=True )
    plugintools.add_item(action="f_terravore", title="Terravore", thumbnail=TERRAVORE, folder=True ) 
       
 ###########################################################
 ################ FESTIVALS ################################
 ###########################################################
 
def festivals(params):
    from logos import logos_festivals
    WACKEN=logos_festivals.wacken(params)
    HELLFEST=logos_festivals.hellfest(params)
    RESURRECTION=logos_festivals.resurrection(params)
    plugintools.add_item(action="f_wacken",title="Wacken", thumbnail=WACKEN, folder=True )  
    plugintools.add_item(action="f_hellfest",title="Hellfest", thumbnail=HELLFEST, folder=True )  
    plugintools.add_item(action="f_resurrection",title="Resurrection Fest", thumbnail=RESURRECTION, folder=True )  


 ###########################################################
 ################ RECORD LABELS ############################
 ###########################################################

def recordlabels(params):
    from logos import logos_labels
    CENTURY=logos_labels.century(params)
    plugintools.add_item(action="f_century",title="Century Media Records", thumbnail=CENTURY, folder=True )  

 ###########################################################
 ################ SPECIAL PLAYLISTS ########################
 ###########################################################
 
def specialplaylists(params):
    from logos import logos_specials
    BEST=logos_specials.best(params)
    plugintools.add_item(action="f_best",title="Best Metal Playlists", thumbnail=BEST, folder=True )
    plugintools.add_item(action="f_spanish",title="Spanish Metal Playlists", thumbnail=BEST, folder=True )  
      
 ###########################################################
 ################ YOUTUBE CHANNELS #########################
 ###########################################################
 
def youtubechannels(params):
    from logos import logos_youtube_channels
    SHAUNTRACK=logos_youtube_channels.shauntrack(params)
    plugintools.add_item(action="f_shauntrack",title="Shaun Track", thumbnail=SHAUNTRACK, folder=True )  
    AMUSIA=logos_youtube_channels.amusia(params)
    plugintools.add_item(action="f_amusia",title="El canal de Amusia", thumbnail=AMUSIA, folder=True )  
      
 ###########################################################
 ################ DOCUMENTARIES ############################
 ###########################################################
 
def documentaries(params):
    from logos import logos_documentaries
    GIBSONTV=logos_documentaries.gibsontv(params)
    ICONS  = "plugin://plugin.video.youtube/playlist/PL7qLGYJiRJ1hr5qFhq3xFlyNNO1iQPjQU/"
    plugintools.add_item( 
        title="Icons - Gibson TV",
        url=ICONS,
        thumbnail=GIBSONTV, folder=True )  

 ###########################################################
 ################ METAL GENRES #############################
 ###########################################################
 
def genres(params):
    from logos import logos_genres
    GENRES=logos_genres.genres(params)
    plugintools.add_item(action="f_power",title="Power", thumbnail=GENRES, folder=True )  
    plugintools.add_item(action="f_thrash",title="Thrash", thumbnail=GENRES, folder=True )       
      
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()
    
    
    
####### Añadir:  documentales 
# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
    
    plugintools.add_item( 
        action="bands", 
        title="Bands",
        #url="",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3eElb6lCwWPG9t29fTLR-N3A8ZJf2Lm_xQFdbvdqCs9OFofxWNQl68R_gMbIBZay1KgAELYMAa67908BrosdQSR1SXchSJTXCByakz6yhQjjnVeeJVeDZyKlGX-ETCN2qv_9pU39bQIwcJwXIdm1NZM=w1260-h934-no",
        folder=True )  
          
    plugintools.add_item( 
        action="festivals", 
        title="Festivals",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE=w1200-h800-no",
        folder=True ) 


    plugintools.add_item( 
        action="recordlabels", 
        title="Record Labels",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3f9mObJ62-yVFTqP2uszerfM3ZZIOgLc36hlaSQceOthe6-x_H99h1fuYI2jwo7HixRxrOKQdu3XDx2huz_zFkGa60hDvV0288klgL9LEAvXmQZ2dpI1VGcgSzxykcrINpiGELadx7Ddw9Rv5e7rOVh=w1007-h950-no",
        folder=True ) 

    plugintools.add_item( 
        action="specialplaylists", 
        #action="recordlabels",
        title="Special Playlists",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3dsK7o1DkntMB2Mz0oa9_t75EbfksTVBzwZa6pt7spRTaj4Gn9ZHJZ94BPu-sKfU4vxI4JNJ8n_WvUn4R1BIygkheSdfe_2jfNB6ws2AqU9-xFx_0Jsp0GIbJNfx730ae4W_DyCZGjc288DRGTgPxJO=w1200-h799-no",
        folder=True ) 
        
    plugintools.add_item( 
        action="youtubechannels", 
        title="YouTube Channels",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3dOGT6ZqPuhDvtgme1Y3_XsvLSe5xGJwN1sRYpahcmgvEEmaJ-CzpVWVKNFRqGdKLymtkr51jwNUDMSKdZQtS59SG9ZUqS80pZK3vgcz_puYmb0OBMyLK1bF1uhoICaFqfH4Dt6UpHqlJ_E_zcscwWu=s512-no",
        folder=True )
        

    plugintools.add_item( 
        action="documentaries", 
        title="Documentaries",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ewWRgvKtJDMT_c2Kwl5gRuqG2PFRja4ZTltPqHxWCwpfU0sCJ0AIj_i3H4gc8N1Lc6-NnvJT79fPBpJ7OaGsUFGscKUf1DmosH-8IFq4vAGyBpFAW94AJd2zR-D_3oyrd5Xg1XnLjQzYdWt8na6dVF=w919-h950-no",
        folder=True )
        
    plugintools.add_item( 
        action="genres", 
        title="Videos by Metal Genres",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3esTCgba7_ixI4yN2VClVitMg9iahmyjo-e871kVFuonYhFcLvJVsrbyRsQhhjL0s-kCirwii5CVAB5vENwOA51vx3CKZCOAZDx7pDsiZt7figuFO7ASTUh_8QVP8_WJI5RGskFMI8AZ0XzAOhtD3FE=w1280-h780-no",
        folder=True )
run()
