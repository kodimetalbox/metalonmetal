# -*- coding: utf-8 -*-
#------------------------------------------------------------
import plugintools
from logos import logos_genres

NUCLEARBLAST = "plugin://plugin.video.youtube/playlist/PLB4brr7vf-P4ocoTLNNB-tQEao4T5doxp/"
RELAPSE = "plugin://plugin.video.youtube/playlist/PLq6NULtuhFunARjAXTLeb5i_pErL84gnP/"
PLAYLIST = "plugin://plugin.video.youtube/playlist/PL5fRL6A4m-DFl8TkofBGy8uxbZrBbmwhE/"

TMV1  = "plugin://plugin.video.youtube/playlist/PLVQYYTxTxpYdNHHetjaMaZkCVmYK6ZfCL/"
TMV2  = "plugin://plugin.video.youtube/playlist/PLUuCtr3VjoK2VCuqD4WQmd7BZteKLhPAm/"
TMV3  = "plugin://plugin.video.youtube/playlist/PLkdSC3c33L8mradkKNUxDqQl4DM48wMCH/"
TMV4 = "plugin://plugin.video.youtube/playlist/PL9BD30D6B37987485/"
TMV5  = "plugin://plugin.video.youtube/playlist/PLcNmBW5DYbVY1bZSowzo6w-TbIs-79jj7/"
TMV6  = "plugin://plugin.video.youtube/playlist/PLvDtqwUzmWY3A6fcLyuW_IBxCWrfQdF3y/"
TMV7 = "plugin://plugin.video.youtube/playlist/PLE00DBD3756C9D3EA/"


DEATH  = "plugin://plugin.video.youtube/playlist/PLi-xhtW1nwLo1BhZwIpPrfu0rbUodFzXG/"

_80 = "plugin://plugin.video.youtube/playlist/PLda0Q821IKALrCrC0hs7G9qgW8sslXG_m/"
NEWWAVE  = "plugin://plugin.video.youtube/playlist/PL_JE4b6_wstVQCUaM50K8IG7BYAw8kMzW/"
OLDSCHOOL  = "plugin://plugin.video.youtube/playlist/PLvkFzI_b6HNV_pf6ICj4t0dvikjFgXd-J/"


_2019  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztPr_GmXX7qdcr3liV-8y-NZ/"
_2019_  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztP7Mlzos_cuWFTWLIWdCVfl/"
_2018  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztNWd2Rnr5zS5O2j8FXm_1ar/"



NV  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztOf7ch6dr3MCTQV4x0-t8WP/"
LIVE  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztPDS0b3HRV1iM2X-THuy2jo/"
CARTOONS  = "plugin://plugin.video.youtube/playlist/PLhHaGCkTYWKhMCIjrOU0J9WBO-SQxfFQc/"
LIVE2  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztOlYbAybFMGN6T-hVGEG0_u/"

def thrash1(params):
    logo=logos_genres.genres(params)
    plugintools.add_item( 
        title="Thrashing Cartoons [Caricaturas thrashers]",
        url=CARTOONS,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="THRASH METAL / SPEED METAL - Nuclear Blast Records",
        url=NUCLEARBLAST,
        thumbnail=logo, folder=True )  
 
    plugintools.add_item( 
        title="THRASH METAL - Relapse Records",
        url=RELAPSE,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="THRASH METAL PLAYLIST: Official Music Videos only / Old School Speed Death Hardcore Heavy Metal",
        url=PLAYLIST,
        thumbnail=logo, folder=True )     
            
    plugintools.add_item( 
        title="Thrash Metal Videos 1",
        url=TMV1,
        thumbnail=logo, folder=True )
        
   
    plugintools.add_item( 
        title="Thrash Metal Videos 2",
        url=TMV2,
        thumbnail=logo, folder=True )
   
    plugintools.add_item( 
        title="Thrash Metal Videos 3",
        url=TMV3,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Thrash Metal Videos 4",
        url=TMV4,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Thrash Metal Videos 5",
        url=TMV5,
        thumbnail=logo, folder=True )  
  
    plugintools.add_item( 
        title="Thrash Metal Videos 6",
        url=TMV6,
        thumbnail=logo, folder=True )  
      
    plugintools.add_item( 
        title="Thrash Metal Videos 7",
        url=TMV7,
        thumbnail=logo, folder=True )  


    plugintools.add_item( 
        title="Thrash / Death",
        url=DEATH,
        thumbnail=logo, folder=True )  
       
    plugintools.add_item( 
        title="Thrash Metal 80's",
        url=_80,
        thumbnail=logo, folder=True )
        
   
    plugintools.add_item( 
        title="New Wave of Thrash Metal",
        url=NEWWAVE,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Old School Thrash Metal",
        url=OLDSCHOOL,
        thumbnail=logo, folder=True )
       
    plugintools.add_item( 
        title="THRASH METAL NEW SCHOOL 2018",
        url=_2018,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="THRASH METAL NEW SCHOOL 2019 (I)",
        url=_2019,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="THRASH METAL NEW SCHOOL 2019 (II)",
        url=_2019_,
        thumbnail=logo, folder=True )
        
        
        
        
        
    plugintools.add_item( 
        title="THRASH DEATH OLD SCHOOL NEW VIDEOS",
        url=NV,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="THRASH DEATH METAL NEW SCHOOL LIVE",
        url=LIVE,
        thumbnail=logo, folder=True )
        

        
        
    plugintools.add_item( 
        title="OLD SCHOOL METAL LIVE VIDEOS",
        url=LIVE2,
        thumbnail=logo, folder=True )
                


   
