def specials(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dsK7o1DkntMB2Mz0oa9_t75EbfksTVBzwZa6pt7spRTaj4Gn9ZHJZ94BPu-sKfU4vxI4JNJ8n_WvUn4R1BIygkheSdfe_2jfNB6ws2AqU9-xFx_0Jsp0GIbJNfx730ae4W_DyCZGjc288DRGTgPxJO=w1200-h799-no"
    
def best(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3f-T5-Imvz8123qpDNToBgvrmQ4zMBfnzHlQqDw03RNYpf0uq0YpmF0tYPTMJyXIlpJ3rf7BF_XPi5h31YabGj-IPDl3Hn68s9BDYXpJtB0fYjm-ERjTFzjDpFcdD5yvUtc12SNUOkNlEuvS0NQ-SEX=w943-h679-no"
   

