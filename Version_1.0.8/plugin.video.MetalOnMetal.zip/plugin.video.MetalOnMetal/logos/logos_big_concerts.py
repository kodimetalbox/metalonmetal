def bigfour(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3eYsJ9cevw97AH3sgMeAmm-gZ0iZSxSyiXJWorbXRlFu6BdKlHAk9BQKh0HfnAl6WLHiQXXSL_Wqqnd06NS71gjC0BoAsmjehSswzqNpIpZdzLJ_EFbkRZAQEs_91p4GDIPgtCOHz3tEWo9sW6nww8z=w386-h289-no"
   
def moscow(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3f7KAEYa8BWt8TetdrSihaFkktq3hTn4CmIKXrAvbYRTN66hXQV1Z_1hCdqYStD6z3ceAdzx7XQXbK945Sk9Jc3epuH9i0Ont6qmrwVioBZ8s_dJ9_1AQK1sLburQyR8axGGtLPcTp0uxYcaZAD3Sbi=w800-h693-no"

def kiss_03(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLVHNn2g3WybM2gwGKv9ehgQ0gDbxBQkhrnHsPJo0_txytNzUNNvYJIEj6WXk89nPGa60dcD3cMvpJcHXVgTUqTqbdNowVZl9hIHGMCvYVZrNeK8cJ2qzpFDktLoGLL3fZkpPcCPFddIW_gtdctqsVxW=w620-h350-no"

def metallica(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLV3gsrv9fnV8TyApiRVN3LrE4eptk9n0L3NXJDUeKdqTVj06qjTKKTwRbwY6KueSy1g50ZJDumGKk5BOOCR2rT9puNVMQahEud1YeVfwRMomy5L65HqyBMcL5aP84P9BrQeXv11XS7KyZJZF3wXDoSR=w1350-h759-no"

def full_concerts(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLWFYOevR7LnqL7yO5ZNxhseigENz3xtaFXE_WJRERXYWEA4aZFvigz7dqbgw47iJApOvSonSTTAoNQ6IgvR6ZpkNZwtIpJOrW7Xxa1MtFuXjTF8M00ff892_MbNB108V-kU_qcsHHCuQmRbIklgWWf3=w1000-h677-no"
    
def combat_tour(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLVqGeVq20lvDjKdU0bhYlvwqaI-C_WF7YmtTRZGn6LBbfw0NAX4w1SlUm827xvSTu5FMWOflaBBWZa1W8jCIkcnUHnyKmISxH8PgOZ1tfD0I4vmfeTiRqx0D0V9zpEyxXlgXsM30c9wmEFT9pm63SZT=s425-no"

def combat_tour1_vhs(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLVX90tHLPAywAfwTmqqNdNgFOu4VKJH_rR3PnjG4IoRgwy7KjPmRc9BS1A7nv2XKC6SzkoMb3pmOZ6-v379J00Ri_0-RfEmWbV6OMT_4ZLVlFb6RGj8QgsQkA57ud-RZzupdcnp6P4eKdbUYo3xwEbR=w510-h759-no"
    
def combat_tour2_vhs(params):
    return "https://lh3.googleusercontent.com/pw/AM-JKLXNwu849ZDUmldjCxOJJ_gyr8JpW-ebo8Bys-5Vr-pE672ov1spfoia8u59VRGui01TeDb7JJWF9ZFhUwcDvHeVPUAsY0CgcufdFQse3MdaZRqTSl3yDgpAPQ-VOoEi8AqHGX1fApXmZfazITl1MVov=w994-h759-no"
    
'''
def (params):
    return ""
'''
