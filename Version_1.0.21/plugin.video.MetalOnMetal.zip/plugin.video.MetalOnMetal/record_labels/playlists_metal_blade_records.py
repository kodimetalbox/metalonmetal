import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_labels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([  
            [ "Traditional Metal", "PLy8LfIp6j3aKrE7XMm1p-reM4A8y_YHNu"],   
            [ "Maximun Death Metal", "PLy8LfIp6j3aJdMpgsTcMMA3stazpkKK3o"],           
            [ "Progressive / Post Metal", "PLy8LfIp6j3aIBjU6jcEScsqZ6nX0Jxzit"],           
            [ "New and Upcoming Releases", "PLy8LfIp6j3aL9rV6SFKpEWnKmMhsZxaaI"],           
            [ "Classic Metal Blade Throwbacks", "PLy8LfIp6j3aLpfcUnU-jTKPTj2DW6LSpi"],           
            [ "Metal Blade Official Playthroughs", "PLy8LfIp6j3aKoPnnqTixxNBrF0a4TQCtX"],           
            [ "Metal Blade Records 35th Anniversary Tour", "PLy8LfIp6j3aLoNiBITkATS_GSrwEQ9MrK"],
            [ "Live concerts","PLy8LfIp6j3aJAk5XgZKQlz9xSkwkGaRgq"],
            [ "Metal Blade Records 35th Anniversary Tour","PLy8LfIp6j3aLoNiBITkATS_GSrwEQ9MrK"],
            [ "Artillery \"X\" out now","PLy8LfIp6j3aJ-5nWquH2CgWKyeghOxnZ4"],
            [ "Category 7","PLy8LfIp6j3aJmEjewJ_lhbc1LGkbjp55D"],
            [ "DragonForce \"Extreme Power Metal\" out now","PLy8LfIp6j3aITAytcwYvhyeu8sJf6TNlj"],
            [ "In Solitude","PLy8LfIp6j3aKjnO27bIZrFX5dFZ1WXoZP"],
            [ "King Diamond \"Masquerade of Madness\" out now","PLy8LfIp6j3aKbAqlYCOof1rdzts9otHsK"],
            [ "Mercyful Fate","PLy8LfIp6j3aKSGIs4vqHb--9BpihTP5Rg"]])

def playlists(params):
    logo=logos_labels.metal_blade_records(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

