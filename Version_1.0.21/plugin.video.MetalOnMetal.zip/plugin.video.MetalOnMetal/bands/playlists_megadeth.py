import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_bands

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


arrayMenu = ([
            [ "Vevo - Videos from 'The Sick, The Dying... And The Dead!' Album",  "PLw138E0QOEPP9cItQ8LW7S_dOdmJPGcPq"],
            [ "Vevo - Megadeth Videos",  "PL70HZkxYOh3ZjNG29kM98rf49II68USKy"],
            [ "Official Videos",  "PLFJaod-oManE5gpqkzyhbspshu6mL7drM"],
            [ "2016 - Vic and the Rattleheads - Live at St. Vitus",  "PLCGSYpe3gZW68kb48SdbEJyOKbbHPWzah"],
            [ "Live Shows","PLpaC8Xn1qPorwWc4p4uGbgq8G2fS4ZwQG"],
            [ "1980's Live","PLvjJ4mKQyooe1Iv50hH2_ybXm6KUTJXzN"],
            [ "1990's Live","PLvjJ4mKQyoocw8vn4VZbKt_cwcFfNSN37"],
            [ "2000's Live","PLvjJ4mKQyooebeKIWVmcSqsr3pWu6fAI8"],
            [ "2010's Live","PLvjJ4mKQyoof05kmAMFAzckfeU_MP2IXK"],
            [ "2020's Live","PLvjJ4mKQyoocXZ_JrV8P8Ae3nMP0VN-FJ"],
            [ "Acoustic Show","PLYJatCJRsaP9LUA15GMK2UFi6-r556n6S"],
            [ "Unplugged At Musique Plus 2001","PLA794700F94F412CA"],
            [ "From the Vault","PLE1C2952F1D046745"]])
def playlists(params):
    logo=logos_bands.megadeth3(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





