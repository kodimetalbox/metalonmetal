def century(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3clPZFT7nQlDsB9aUCcC5QozWxgsrgHn09qDwiB47sxoQhAloOoBM64PJblGrvRoDTWegePDFLbqVIqCx-PrEGHmop2d_-aVrX67_zRSe2C5naTbwe2vNXW-Ye-cWEVZoWrkzlyybvY_IDZNDHxIkMJ=w797-h950-no"
   
def napalm(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dHH92FDNoPXWxEPSRcXcoZyIlLgnC91O1N32j4ICUNFb5spWIpmUXWe5s7qJ9Sp7GnZVUUh4Q9IEJjrLZD3sRCeGQrCo-gMEaRlIqT5S8DAKMTcO4FZqtrr-X7bBBJxSybntETAuNaXWsIv_pjoR-P=s512-no"
    
def napalm2(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3e_ngWBby3Zc5_jLhfdtiLVxN-XL4Z2pTXzndB5ToRDXsI8mHi4K1ntFuaH5ukQwpZWUN-HX8IKI6wikczCAzbv3cDeA2btowpBQUrRd904JBmzgxYiYXKYLT7IPF35R_d6mhJeEWij9NrmJtnRPeta=s300-no"
    
def nuclear_blast(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3ePHX936xIpa6VYaw6UXMJwxow-GZ6huLA3zXtt1gR0uXZ1nXUoNWeij0tOpjzBMoMdAOaY19WGsQ2HGuk7aCesiyPJ1YeB-I8vJD_wTRttJBPxa3Ugb3KGrBIoCHYuB0fAXw_LR9DOmgZd2N7AYkc=s768-no"
    
def earache(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3cjGVSKg-8CM2JW2OTAD6jSKBdSdheYBzC9NtU-_-vuQatdUW65YZecLWurVfqfPuGhRMwj6kLaXBGMyvHkTyuq2aqYPigSXOEpoMKmQOkKbgQhPP_nFEYQUa2ahmPog8QZFzu_pku1l8ZdS4f9FEr_=w400-h270-no"
    
def massacre(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dv1J7xoh11hon-79NVNnsmZ8zz344Iqi1zTsfhcZf7cwy1250b-WYPgwe4wejgtYV9jleu30nbu2Q5jw9qkjxuksyWgU-y-E7MO--bhBGMv4hwtEK3M6rreQCbZmhsU5XfJ9phsXzhf5mNWpomkQqJ=s600-no"

def metal_blade_records(params):
	return "https://lh3.googleusercontent.com/pw/AL9nZEVA-Ie5bDRDf3YouKDQqXKWlYN4MO1qS05tbKL928nmw-qSIST8ns1piaD2BOONO3Vnlp1LEObOgxobufcsb6VwpbgfIzxODVwaSw3W-Qsds-MhXF3UkSirhMTkUFZec5223el5obFtXl2zaDGxUulH=s759-no"
	
def dying(params):
	return "https://lh3.googleusercontent.com/pw/AP1GczOHzb7Zt9f14fAoHGd-b0vxUE7Ta1n3ExPYBpKbU9UXwcGtgmj5kxyjp99TWsDYFqmgZx88nL2SeZ6DSVmx4fQaJxc2ZLZ4NC2rhUdMqF7T1VmTqbvDzeYJNg1yCKGFgi4AzCi7Qnie3C6kyAlAn1XI=w400-h647-s-no"
