# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon and Duff You
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from logos import logos_guitar

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

xbmc.executebuiltin('Container.SetViewMode(500)')

###########################################################
################ THIRD MENU - PLAYLISTS ###################
###########################################################

### PLAYLISTS BANDS ################################

def function_live_bands(params):
    from bands import playlists_live_bands
    playlists_live_bands.playlists(params)          

def function_acdc(params):
    from bands import playlists_acdc
    playlists_acdc.playlists(params)               

def function_crisix(params):
    from bands import playlists_crisix
    playlists_crisix.playlists(params)

def function_megadeth(params):
    from bands import playlists_megadeth
    playlists_megadeth.playlists(params)          
      

### PLAYLISTS FESTIVALS ###################################

def function_wacken_by_year(params):
    from festivals import playlists_wacken_by_year
    playlists_wacken_by_year.playlists(params) 
    
def function_wacken_year_after_year(params):
    from festivals import playlists_wacken_all_clips
    playlists_wacken_all_clips.playlists(params)    

def function_wacken_by_genre(params):
    from festivals import playlists_wacken_by_genre
    playlists_wacken_by_genre.playlists(params) 

def function_hellfest(params):
    from festivals import playlists_hellfest
    playlists_hellfest.playlists(params) 

def function_resurrection(params):
    from festivals import playlists_resurrection
    playlists_resurrection.playlists(params) 
  
def function_rock_hard_festival(params):
    from festivals import playlists_rock_hard_festival
    playlists_rock_hard_festival.playlists(params)   

def function_bloodstock(params):
    from festivals import playlists_bloodstock
    playlists_bloodstock.playlists(params) 
   
def function_summer_breeze(params):
    from festivals import playlists_summer_breeze
    playlists_summer_breeze.playlists(params) 

def function_rockstadt_fest(params):
    from festivals import playlists_rockstadt_fest
    playlists_rockstadt_fest.playlists(params) 
    
   

### PLAYLISTS BIG CONCERTS ################################

def function_bigfour(params):
    from big_concerts import playlists_bigfour
    playlists_bigfour.playlists(params) 
  
def function_berlin90(params):
    from big_concerts import playlists_berlin90
    playlists_berlin90.playlists(params) 
    
def function_moscow(params):
    from big_concerts import playlists_moscow
    playlists_moscow.playlists(params) 
  

def function_kiss(params):
    from big_concerts import playlists_kiss
    playlists_kiss.playlists(params) 
  
def function_metallica(params):
    from big_concerts import playlists_metallica
    playlists_metallica.playlists(params) 
  
def function_combat_tour(params):
    from big_concerts import playlists_combat_tour
    playlists_combat_tour.playlists(params)     

def function_full_concerts(params):
    from big_concerts import playlists_full_concerts
    playlists_full_concerts.playlists(params)  
    
    
def function_my_favourite_concerts(params):
    from big_concerts import playlists_my_favourite_concerts
    playlists_my_favourite_concerts.playlists(params)  
    
    
#def function_live_bands(params):
    #from bands import playlists_live_bands
    #playlists_live_bands.playlists(params)          
   
### PLAYLISTS RECORD LABELS ################################

def function_century_media(params):
    from record_labels import playlists_century_media
    playlists_century_media.playlists(params) 
 
def function_napalm(params):
    from record_labels import playlists_napalm
    playlists_napalm.playlists(params) 

def function_nuclear_blast(params):
    from record_labels import playlists_nuclear_blast
    playlists_nuclear_blast.playlists(params) 

def function_earache(params):
    from record_labels import playlists_earache
    playlists_earache.playlists(params) 

def function_massacre(params):
    from record_labels import playlists_massacre
    playlists_massacre.playlists(params)  

def function_metal_blade_records(params):
    from record_labels import playlists_metal_blade_records
    playlists_metal_blade_records.playlists(params)     

def function_dying_victims_productions(params):
    from record_labels import playlists_dying_victims_productions
    playlists_dying_victims_productions.playlists(params) 
    

### PLAYLISTS YOUTUBE CHANNELS ################################

def function_metalfever(params):
    from youtube_channels import playlists_metalfever
    playlists_metalfever.playlists(params) 

def function_shauntrack(params):
    from youtube_channels import playlists_shauntrack
    playlists_shauntrack.playlists(params) 

def function_amusia(params):
    from youtube_channels import playlists_amusia
    playlists_amusia.playlists(params) 

def function_juancaraes(params):
    from youtube_channels import playlists_juancaraes
    playlists_juancaraes.playlists(params) 
    
    
def function_bass_channel(params):
    from youtube_channels import playlists_bass_channel
    playlists_bass_channel.playlists(params) 

def function_ironmadness(params):
    from youtube_channels import playlists_ironmadness
    playlists_ironmadness.playlists(params) 
    
### PLAYLISTS OTHER STUFF ################################
def function_f1(params):
    from other_stuff import playlists_f1
    playlists_f1.playlists(params) 

    
###########################################################
################ SECOND MENU ##############################
###########################################################

def bands(params):
    from logos import logos_bands
    
    logo_full_concerts=logos_bands.full_concerts(params) 
    plugintools.add_item(action="function_live_bands",title="Live Bands", thumbnail=logo_full_concerts, folder=True )

    
    logo_full_concerts2=logos_bands.acdc(params) 
    plugintools.add_item(action="function_acdc",title="AC/DC", thumbnail=logo_full_concerts2, folder=True )
    
    logo_full_concerts2=logos_bands.crisix(params) 
    plugintools.add_item(action="function_crisix",title="Crisix", thumbnail=logo_full_concerts2, folder=True )    

    logo_full_concerts=logos_bands.megadeth3(params)
    plugintools.add_item(action="function_megadeth",title="Megadeth", thumbnail=logo_full_concerts, folder=True )

    logo_metallica=logos_bands.metallica(params)
    plugintools.add_item(action="function_metallica",title="Metallica", thumbnail=logo_metallica, folder=True )             
    

 
def festivals(params):
    from logos import logos_festivals

    logo_wacken=logos_festivals.wacken(params)
    plugintools.add_item(action="function_wacken_by_year",title="Wacken Full Concerts (by Year)", thumbnail=logo_wacken, folder=True )  
    plugintools.add_item(action="function_wacken_by_genre",title="Wacken (by Genre)", thumbnail=logo_wacken, folder=True )   
    plugintools.add_item(action="function_wacken_year_after_year",title="Wacken All Clips (by Year)", thumbnail=logo_wacken, folder=True )   

    logo_hellfest=logos_festivals.hellfest(params)
    plugintools.add_item(action="function_hellfest",title="Hellfest", thumbnail=logo_hellfest, folder=True ) 
 
    logo_resurrection=logos_festivals.resurrection(params)
    plugintools.add_item(action="function_resurrection",title="Resurrection", thumbnail=logo_resurrection, folder=True ) 
  
    logo_rock_hard_festival=logos_festivals.rock_hard_festival(params)
    plugintools.add_item(action="function_rock_hard_festival",title="Rock Hard Festival", thumbnail=logo_rock_hard_festival, folder=True ) 
    
    logo_summer_breeze=logos_festivals.summer_breeze(params)
    plugintools.add_item(action="function_summer_breeze",title="Summer Breeze", thumbnail=logo_summer_breeze, folder=True ) 
    
    logo_bloodstock=logos_festivals.bloodstock(params)
    plugintools.add_item(action="function_bloodstock",title="Bloostock", thumbnail=logo_bloodstock, folder=True )    
     
    logo_rockstadt_fest=logos_festivals.rockstadt_fest(params)
    plugintools.add_item(action="function_rockstadt_fest",title="RockStadt Fest", thumbnail=logo_rockstadt_fest, folder=True ) 


def big_concerts(params):
    from logos import logos_big_concerts
    
    #logo_full_concerts=logos_big_concerts.full_concerts(params) 
    #plugintools.add_item(action="function_live_bands",title="Live Bands", thumbnail=logo_full_concerts, folder=True )

    logo_full_concerts=logos_big_concerts.full_concerts(params) 
    plugintools.add_item(action="function_my_favourite_concerts",title="My Favourite Concerts", thumbnail=logo_full_concerts, folder=True )  

    logo_b4=logos_big_concerts.bigfour(params)
    plugintools.add_item(action="function_bigfour",title="The Big Four", thumbnail=logo_b4, folder=True ) 
    

    logo_berlin90=logos_big_concerts.berlin90(params) 
    plugintools.add_item(action="function_berlin90",title="Live East Berlin 1990", thumbnail=logo_berlin90, folder=True )   
    
    logo_metallica=logos_big_concerts.metallica(params) 
    plugintools.add_item(action="function_metallica",title="On Tour with Metallica", thumbnail=logo_metallica, folder=True )             
      
    logo_moscow=logos_big_concerts.moscow(params) 
    plugintools.add_item(action="function_moscow",title="Moscow Music Peace Festival", thumbnail=logo_moscow, folder=True )

    logo_combat_tour=logos_big_concerts.combat_tour(params) 
    plugintools.add_item(action="function_combat_tour",title="Combat Tour", thumbnail=logo_combat_tour, folder=True )   
    
    logo_full_concerts=logos_big_concerts.full_concerts(params) 
    plugintools.add_item(action="function_full_concerts",title="Full Concerts", thumbnail=logo_full_concerts, folder=True )  


def record_labels(params):

    from logos import logos_labels
    
    logo_century=logos_labels.century(params)
    plugintools.add_item(action="function_century_media",title="Century Media", thumbnail=logo_century, folder=True ) 
    
    logo_napalm=logos_labels.napalm2(params)
    plugintools.add_item(action="function_napalm",title="Napalm Records", thumbnail=logo_napalm, folder=True )  
    
    logo_nuclear_blast=logos_labels.nuclear_blast(params)
    plugintools.add_item(action="function_nuclear_blast",title="Nuclear Blast", thumbnail=logo_nuclear_blast, folder=True )
    
    logo_earache=logos_labels.earache(params)
    plugintools.add_item(action="function_earache",title="Earache Records", thumbnail=logo_earache, folder=True ) 
    
    logo_massacre=logos_labels.massacre(params)      
    plugintools.add_item(action="function_massacre",title="Massacre Records", thumbnail=logo_massacre, folder=True )
    
    logo_metal_blade_records=logos_labels.metal_blade_records(params)      
    plugintools.add_item(action="function_metal_blade_records",title="Metal Blade Records", thumbnail=logo_metal_blade_records, folder=True )
    
    logo_dying=logos_labels.dying(params)
    plugintools.add_item(action="function_dying_victims_productions",title="Dying Victims Productions", thumbnail=logo_dying, folder=True )     
    
def youtube_channels(params):

    from logos import logos_youtube_channels
    
    logo_metalfever=logos_youtube_channels.metalfever(params)
    plugintools.add_item(action="function_metalfever",title="Metal Fever Podcast", thumbnail=logo_metalfever, folder=True ) 
  
    logo_shauntrack=logos_youtube_channels.shauntrack(params)
    plugintools.add_item(action="function_shauntrack",title="ShaunTrack", thumbnail=logo_shauntrack, folder=True ) 
        
    logo_amusia=logos_youtube_channels.amusia(params)
    plugintools.add_item(action="function_amusia",title="El canal de Amusia", thumbnail=logo_amusia, folder=True ) 
    
    logo_juancaraes=logos_youtube_channels.juancaraes(params)
    plugintools.add_item(action="function_juancaraes",title="Juancaraes", thumbnail=logo_juancaraes, folder=True )  
    
    logo_bass_channel=logos_youtube_channels.bass_channel(params)
    plugintools.add_item(action="function_bass_channel",title="The Bass Channel", thumbnail=logo_bass_channel, folder=True )  
    
    logo_08=logos_guitar.logo_08(params)
    plugintools.add_item(action="function_ironmadness",title="Iron Madness Podcast", thumbnail=logo_08, folder=True ) 
  

def other_stuff(params):

    from logos import logos_youtube_channels
    
    logo_metalfever=logos_youtube_channels.metalfever(params)
    plugintools.add_item(action="function_f1",title="F1", thumbnail=logo_metalfever, folder=True ) 


###########################################################
################ FUNCTION RUN() ###########################
###########################################################
def run():
    plugintools.log("docu.run")

    # Obteniendo parámetros...
    params = plugintools.get_params()


    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec(action+"(params)")

    plugintools.close_item_list()            

###########################################################
################ MAIN MENU #############################
###########################################################
def main_list(params):
    logo_01=logos_guitar.logo_01(params)
    logo_02=logos_guitar.logo_02(params)
    logo_03=logos_guitar.logo_03(params)
    logo_04=logos_guitar.logo_04(params)
    logo_05=logos_guitar.logo_05(params)
    logo_06=logos_guitar.logo_06(params)
    logo_07=logos_guitar.logo_07(params)
    logo_08=logos_guitar.logo_08(params)
    logo_09=logos_guitar.logo_09(params)
    logo_10=logos_guitar.logo_10(params)
    logo_11=logos_guitar.logo_11(params)
    logo_12=logos_guitar.logo_12(params)
    logo_13=logos_guitar.logo_13(params)
    logo_addon=logos_guitar.logo_duffyou_youtube3(params)

    
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        action="bands", 
        title="Bands",
        thumbnail=logo_01,
        folder=True )         
       
                  
    plugintools.add_item( 
        action="festivals", 
        title="Festivals",
        thumbnail=logo_02,
        folder=True ) 


    plugintools.add_item( 
        action="big_concerts", 
        title="Big Concerts",
        thumbnail=logo_03,
        folder=True )    


    plugintools.add_item( 
        action="record_labels", 
        title="Record Labels",
        thumbnail=logo_04,
        folder=True ) 
        

    plugintools.add_item( 
        action="youtube_channels", 
        title="YouTube Channels",
        thumbnail=logo_05,
        folder=True ) 
 
 
    plugintools.add_item( 
        action="other_stuff", 
        title="Other stuff",
        thumbnail=logo_06,
        folder=True ) 
                                       
                    
    plugintools.add_item( 
        action="", 
        title="You can chosse DuffYou or YouTube in Add-on Settings",
        thumbnail=logo_addon,
        folder=False )


run()
