import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_youtube_channels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Videos 2024",  "PLe_OWxpTcSPSLufYJ7J6s3ql0WQ_QzSAA"],
            [ "Videos 2023",  "PLe_OWxpTcSPThjCyji4fMB6meEvorzzll"],
            [ "Videos 2022",  "PLe_OWxpTcSPRjZVenk6KUFuTnNWS5NVse"],
            [ "Reseñas Retro Carlos",  "PLe_OWxpTcSPTJWMEPDPWquWh51P79Hhoj"],
            [ "Reseñas Clásicos Manuel",  "PLe_OWxpTcSPTbE2sF9hJk-ymXYjkUDYUV"],
            [ "Reseñas Metal Latinoamericano",  "PLe_OWxpTcSPQYQPIJjenB-Yxo5a00Jx0B"],
            [ "Charlas y opiniones",  "PLe_OWxpTcSPTmps1GqAb4XR9gKdnpekf-"]])

def playlists(params):
    logo=logos_youtube_channels.amusia(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

