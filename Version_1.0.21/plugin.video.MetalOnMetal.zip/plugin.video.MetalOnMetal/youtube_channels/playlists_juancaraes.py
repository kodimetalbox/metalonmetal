import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_youtube_channels


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Historia de Extremoduro",  "PLw8mhhLAgwQNDsKcKqaDYi2yFHOT5ZBMp"],
            [ "Entrevistas a otros personajes",  "PLw8mhhLAgwQNM38lM-RldsHymz1_Dg-rE"],
            [ "Directos",  "PLw8mhhLAgwQMi1DGrwJCDeaUZNg51N7PB"],
            [ "Reviews",  "PLw8mhhLAgwQOMFM4yobRHGi6ZAOwRQkyi"],
            [ "Conciertos",  "PLw8mhhLAgwQN1Y0TgA1EuNsrjuKyaGX6q"],
            [ "Entrevistas",  "PLw8mhhLAgwQNgcXVgINog4Y-7glz7yKdX"],
            [ "Ruedas de prensa y entrega de premios",  "PLw8mhhLAgwQNgRsngXpgTHhsKeE2eTi7P"]])

def playlists(params):
    logo=logos_youtube_channels.juancaraes(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

