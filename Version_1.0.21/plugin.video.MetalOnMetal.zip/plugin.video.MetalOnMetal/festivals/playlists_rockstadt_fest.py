import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

id_YEAR_2017 = "PLGuhlLazJwGuSiBO1Et3LvZXdAvqKP1UH" 
id_YEAR_2016 = "PLGuhlLazJwGuOwIGgQp4h2ddpFrei8ijK" 
id_YEAR_2015 = "PLGuhlLazJwGs0ICanv7SJHg0qdydvmidE" 
id_YEAR_2014 = "PLGuhlLazJwGv084aQVT6hTPywta16US6L"  

if usa_duffyou:  ##Usamos plugin Duff You
    YEAR_2014 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2014).encode('utf-8')).decode('utf-8')
    YEAR_2015 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2015).encode('utf-8')).decode('utf-8')
    YEAR_2016 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2016).encode('utf-8')).decode('utf-8')
    YEAR_2017 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2017).encode('utf-8')).decode('utf-8')
    
    # = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_).encode('utf-8')).decode('utf-8')

else:  ##Usamos pluin YouTube
	YEAR_2014 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2014)
	YEAR_2015 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2015)
	YEAR_2016 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2016)
	YEAR_2017 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2017)

    # =  youtube.replace("MI-ID-PLAYLIST" , id_)


def playlists(params):
    logo=logos_festivals.rockstadt_fest(params)
 
    plugintools.add_item( 
        title="RockStadt Extreme Fest 2017",
        url=YEAR_2017,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="RockStadt Extreme Fest 2016",
        url=YEAR_2016,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="RockStadt Extreme Fest 2015",
        url=YEAR_2015,
        thumbnail=logo, folder=True )
 
    plugintools.add_item( 
        title="RockStadt Extreme Fest 2014",
        url=YEAR_2014,
        thumbnail=logo, folder=True )
 

