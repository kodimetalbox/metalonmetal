import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals

setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "Wacken 2024", "PLPfPNs01OQC1OQVgoYNdAUSthUNzxNlZD" ],
            [ "Wacken 2023", "PLPfPNs01OQC2DClAnNz-bVa5Wi5_yZfSh" ],
            [ "Wacken 2022", "PLPfPNs01OQC3jBn4iQNKwEnezbAk7vqKn" ],
            [ "Wacken 2020", "PLPfPNs01OQC2M9X9CEgnCc6sX617ClFof" ],
            [ "Wacken 2019", "PLPfPNs01OQC2KzJbYebTDyo2z7J3D-Ss0" ],
            [ "Wacken 2018", "PLPfPNs01OQC3lGQh5ge9x8XB2Rpqt0V2n" ],
            [ "Wacken 2017", "PLPfPNs01OQC2ncq-F56xNLHfAX0v91TP4" ],
            [ "Wacken 2016", "PLPfPNs01OQC22ikUUW2BOzge27-VAEwQf" ],
            [ "Wacken 2015", "PLPfPNs01OQC3T_ZdSPPC0s7gz2vzP7wIw" ],
            [ "Wacken 2014", "PLPfPNs01OQC3WpWK6MAfKTUsJDuZ4nwvM" ],
            [ "Wacken 2013", "PLPfPNs01OQC12Ip5gcbtsZqHfCVqvupvJ" ],
            [ "Wacken 2012", "PLPfPNs01OQC1x1v91zv0sYZ89Ld3zE-rg" ],
            [ "Wacken 2011", "PLPfPNs01OQC0SWNXRaqTlMKVhucD6OSVd" ],
            [ "Wacken 2009", "PLPfPNs01OQC37p9V0YXCV49H_Y3KzI83E" ],
            [ "Wacken 2008", "PLPfPNs01OQC1GBti0v9shxdl6WHDm6cSz" ],
            [ "Wacken 2007", "PLPfPNs01OQC1175sDqcu88wbVgtuFQhIx" ],
            [ "Wacken 2006", "PLPfPNs01OQC3RGPlJiBauUJM4qDs7jiXZ" ]])

def playlists(params):
    logo=logos_festivals.wacken(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )





