import plugintools


from logos import logos_guitar


_280 = "plugin://plugin.video.youtube/playlist/PLlIXsXPSwnwkGGLTcot2_HU1lOz_2GFOZ/"
_100  = "plugin://plugin.video.youtube/playlist/PLqYXv_L7NiEwLmwbd6wgF6VxOQSOOBLzT/"
_2020 = "plugin://plugin.video.youtube/playlist/PLEOX-VnEHlPRu7U2yp8bII4UPjHaturg3/"
PMV1  = "plugin://plugin.video.youtube/playlist/PL60Q0TM9-n91QCgogAMOSLYZqbECVKRse/"
PMV2 = "plugin://plugin.video.youtube/playlist/PLv3coDEywtCsUwNw92pPzCJbaU8O6K3St/"
PMV3  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztM9ah_DEhwSz--tGa5SUMr2/"
PMV4 = "plugin://plugin.video.youtube/playlist/PLYThEbJw1F5HZwq0nV_XJPsGfqF1nod5s/"
PMV5  = "plugin://plugin.video.youtube/playlist/PLY9STb3JkzdXvTTW0Qw44ChgtBLN6ARBe/"
PMV6  = "plugin://plugin.video.youtube/playlist/PLDxJzC_UMTd53v2bSY3D_Z1Fk0e1uWzkB/"
PMV7  = "plugin://plugin.video.youtube/playlist/PLNU7VP43E5uBiRDOeSf-GG6rskanbytN7/"
PMV8  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztOJV0O_rSSHPCT6f8pYjccs/"
PMV9  = "plugin://plugin.video.youtube/playlist/PLXg-lxs-OztOJV0O_rSSHPCT6f8pYjccs/"



def power1(params):
    logo=logos_guitar.logo_07(params)


    plugintools.add_item( 
        title="Best Power Metal Songs of All Time EVER! 280 Bands on 1 Playlist",
        url=_280,
        thumbnail=logo, folder=True )  
       
            
    plugintools.add_item( 
        title="Power Metal Music Video Education: 270 Official Music Videos",
        url=_100,
        thumbnail=logo, folder=True )
       
   
    plugintools.add_item( 
        title="Best 2020s Power Metal Songs!",
        url=_2020,
        thumbnail=logo, folder=True )  
       
    plugintools.add_item( 
        title="Power Metal Videos (I)",
        url=PMV1,
        thumbnail=logo, folder=True )
   
   
    plugintools.add_item( 
        title="Power Metal Videos (II)",
        url=PMV2,
        thumbnail=logo, folder=True )
        
   
    plugintools.add_item( 
        title="Power Metal Videos (III)",
        url=PMV3,
        thumbnail=logo, folder=True )
       
    plugintools.add_item( 
        title="Power Metal Videos (IV)",
        url=PMV4,
        thumbnail=logo, folder=True )
    
       
    plugintools.add_item( 
        title="Power Metal Videos (V)",
        url=PMV5,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Power Metal Videos (VI)",
        url=PMV6,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Power Metal Videos (VII)",
        url=PMV7,
        thumbnail=logo, folder=True )
    
    plugintools.add_item( 
        title="Power Metal Videos (VIII)",
        url=PMV8,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Power Metal Videos (IX)",
        url=PMV9,
        thumbnail=logo, folder=True )
        


