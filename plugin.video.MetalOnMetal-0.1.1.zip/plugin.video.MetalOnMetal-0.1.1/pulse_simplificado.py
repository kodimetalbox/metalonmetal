# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon, xbmcgui
try:
    from urllib import urlretrieve
except:
    from urllib.request import urlretrieve
try:
    from xbmc import translatePath
except:
    from xbmcvfs import translatePath
from logos import logos_guitar

addonID = 'plugin.video.MetalOnMetal-0.1.0'
local = xbmcaddon.Addon(id=addonID)

xbmc.executebuiltin('Container.SetViewMode(500)')



### BANDS
def f_accept(params):
    from bands import accept
    accept.accept1(params)

 ### BANDS           
def bands(params):
    from logos import logos_bands
    ACCEPT=logos_bands.accept(params)
    plugintools.add_item(action="f_accept",title="Accept", thumbnail=ACCEPT, folder=True )  

                  
def run():
    plugintools.log("docu.run")
            
    # Get params
    params = plugintools.get_params()
            
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec (action+"(params)")
            
        plugintools.close_item_list()

class Updater:
    def __init__(self):
        import xml.etree.ElementTree as ET
        self.current_version = local.getAddonInfo("version")
        self.source = "https://kodimetalbox.github.io/metalonmetal/"
        self.data = plugintools.read(self.source)
        self.tree = ET.fromstring(self.data)
        self.parse = self.tree.findall('body')[0]
        self.href = (self.parse.findall('a')[0].get('href'))
        self.remote_version = self.href.split('-')[1].split(".zip")[0]
    def check(self):
        if self.current_version <= self.remote_version: 
            return True
        else:
            urlretrieve(self.source + self.href, os.path.join(plugintools.get_runtime_path(), self.href))
            from zipfile import ZipFile
            dir = ZipFile ( os.path.join(plugintools.get_runtime_path(), self.href) , 'r' )
            dir . extractall ( translatePath(os.path.join('special://home/addons','')))
            dir . close ( )
            os.remove(os.path.join(plugintools.get_runtime_path(), self.href))
            xbmcgui.Dialog().notification( local.getAddonInfo("name") , "[COLOR limegreen]Addon actualizado, vuelva a entrar[/COLOR]" )
            return False
    
    
####### Añadir:  documentales 
# Main menu
def main_list(params):
    #if Updater().check()==True:
        #from logos import logos_guitar
    logo_01=logos_guitar.logo_01(params)

    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        action="bands", 
        title="Bands",
        thumbnail=logo_01,
        folder=True )  
            

run()
