import plugintools


from logos import logos_guitar


S01 = "plugin://plugin.video.youtube/playlist/PLHhnSlk9gsBF_1uxY2Fed_d5LqsLL2C1Z/"
S02 = "plugin://plugin.video.youtube/playlist/PL61B58F901D788E0B/"
S03 = "plugin://plugin.video.youtube/playlist/PLBeuWYds4ybYBhNzQoC3rmovhgA1nnsmq/"
S04 = "plugin://plugin.video.youtube/playlist/PL1O0BXcFuRidZ-VNsQ2Hr_75gUCbBDkQM/"
S05 = "plugin://plugin.video.youtube/playlist/PLfqJXV6ziSXKjMjfhI0QVc4CcRqgjKEXb/"
S06 = "plugin://plugin.video.youtube/playlist/PLpLvEF4NF0RGr43ZZDeCgRmFQCCnN1nwW/"
S07 = "plugin://plugin.video.youtube/playlist/PLpLvEF4NF0RGr43ZZDeCgRmFQCCnN1nwW/"
S08 = "plugin://plugin.video.youtube/playlist/PL9D82A8FCBF99C31D/"


def symphonic1(params):
    logo=logos_guitar.logo_07(params)


   
    plugintools.add_item( 
        title="Sympohonic Music Videos (I)",
        url=S01,
        thumbnail=logo, folder=True )  
       
            
   
    plugintools.add_item( 
        title="Sympohonic Music Videos (II)",
        url=S02,
        thumbnail=logo, folder=True )  
       
            
   
    plugintools.add_item( 
        title="Sympohonic Music Videos (III)",
        url=S03,
        thumbnail=logo, folder=True )  
       
            
   
    plugintools.add_item( 
        title="Sympohonic Music Videos (IV)",
        url=S04,
        thumbnail=logo, folder=True )  
       
            

    plugintools.add_item( 
        title="Sympohonic Music Videos (V)",
        url=S05,
        thumbnail=logo, folder=True )  
 
            

    plugintools.add_item( 
        title="Sympohonic Music Videos (VI)",
        url=S06,
        thumbnail=logo, folder=True )  
 
     
    plugintools.add_item( 
        title="Sympohonic Music Videos (VII)",
        url=S07,
        thumbnail=logo, folder=True )  
 
     
    plugintools.add_item( 
        title="Sympohonic Music Videos (VIII)",
        url=S08,
        thumbnail=logo, folder=True )  
 
        
