import plugintools
#from logos import logos_bands

from logos import logos_labels


L1  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWav--o9BD2BP-kOuB1Aelutd/"
L2  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWauKeCABMeNN7SjjMgAuKju_/"
L3  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWasZt75LNkqhyALv4jd7tIhk/"
L4  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWauH3g41vOUlmP_hOTG2AsBT/"
L5  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWaszlTDt0LJLSvibd2gGGENZ/"

L6  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWauwbcg4tvS35xB53cZCNV7o/"
L7  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWavBHYof1SCaXGtE4WsUDt5y/"
L8  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWasZT_GqxpqRVqXraqrylA13/"

L9  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWaupOrk4Ql2JmuMdnmoSzZbU/"
L10  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWatvtxG7ig1X7U2fsFwVPwDl/"
L11  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWauglqetlLk4VIyrbIa26mOc/"

L12  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWavJ2T928vXjAFLHw6gJKf4H/"
L13  = "plugin://plugin.video.youtube/playlist/PLwnziV82UWat3FEzBnyEK4Oe3feb7mjV_/"
L14 = "plugin://plugin.video.youtube/playlist/PLwnziV82UWavUPnbtMsv7oQwZtfq63weG/"

def function(params):
    logo=logos_labels.massacre(params)
        

    plugintools.add_item( 
        title="Official Videos",
        url=L1,
        thumbnail=logo, folder=True )  
         


    plugintools.add_item( 
        title="The Best Of Massacre Records",
        url=L2,
        thumbnail=logo, folder=True )  
        
        
    plugintools.add_item( 
        title="Lyric Videos",
        url=L3,
        thumbnail=logo, folder=True )  

 
    plugintools.add_item( 
        title="Hard Rock",
        url=L4,
        thumbnail=logo, folder=True )  

 
    plugintools.add_item( 
        title="Heavy Metal",
        url=L5,
        thumbnail=logo, folder=True )  
                



    plugintools.add_item( 
        title="Power Metal",
        url=L6,
        thumbnail=logo, folder=True )  
        

        
    plugintools.add_item( 
        title="Gothic Metal",
        url=L7,
        thumbnail=logo, folder=True )  



    plugintools.add_item( 
        title="Female Fronted Metal",
        url=L8,
        thumbnail=logo, folder=True )  
        





    plugintools.add_item( 
        title="Progressive Metal",
        url=L9,
        thumbnail=logo, folder=True )  
        
    plugintools.add_item( 
        title="Melodic Metal ",
        url=L10,
        thumbnail=logo, folder=True )  
        



    plugintools.add_item( 
        title="Thrash Metal",
        url=L11,
        thumbnail=logo, folder=True )  
        


    plugintools.add_item( 
        title="Death Metal",
        url=L12,
        thumbnail=logo, folder=True )  
        


    plugintools.add_item( 
        title="Doom Metal",
        url=L13,
        thumbnail=logo, folder=True )  
        
 

    plugintools.add_item( 
        title="Full Albums",
        url=L14,
        thumbnail=logo, folder=True )  
        
 
        
 
