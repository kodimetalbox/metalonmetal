# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_big_concerts

N1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGsXWOx3R5JuHznp2mMwAzDI/"
N2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuTUQVRtgJeNqVaTZobt1Ld/"


def bigfour1(params):
    logo=logos_big_concerts.bigfour(params) 
    
    
    plugintools.add_item( 
        title="The Big Four - Live Sofia 2010",
        url=N1,
        thumbnail=logo, folder=True )  


    plugintools.add_item( 
        title="The Big Four - Live at Ullevi 2011",
        url=N2,
        thumbnail=logo, folder=True )  
