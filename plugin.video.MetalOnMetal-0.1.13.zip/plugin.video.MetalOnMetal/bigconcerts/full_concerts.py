# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_guitar


N0 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvWsd-Um02vHrRsx-n2sX4G/"
N1 = "plugin://plugin.video.youtube/playlist/PLuoBnWTW40Msf7SnQfcakGUSlhJCLwNzZ/"
N2 = "plugin://plugin.video.youtube/playlist/PLeoiBqD9wuZ2rhjqNlP0zEY7nypWg8_2t/"
N3 = "plugin://plugin.video.youtube/playlist/PLmYNgzG7_vMg5ZnjA5A6Vyr9Y3xJ2OO9t/"
N4 = "plugin://plugin.video.youtube/playlist/PLhWbPRawCyD7tsHb3VMcAvdYO50sc7E1B/"
N5 = "plugin://plugin.video.youtube/playlist/PLHrguy3J2ka2NrIba_vzXMw6ZCOSeJagd/"
N6 = "plugin://plugin.video.youtube/playlist/PLHrguy3J2ka2r2ZqshbZSKNfLJ4AW_yUj/"
N7 = "plugin://plugin.video.youtube/playlist/PLpPPrzGMnMUlaa__5yBIstqQn1dsVD_QA/"
N8 = "plugin://plugin.video.youtube/playlist/PL_fi_PxIa4WMiCkNx1jt60MN8CKs9-383/"
N9 = "plugin://plugin.video.youtube/playlist/PLpPPrzGMnMUklONYu4E273UImJiZfxE8f/"
N10 = "plugin://plugin.video.youtube/playlist/PLpPPrzGMnMUkM9OWhvAm8VrceuZZCjzcV/"
N11 = "plugin://plugin.video.youtube/playlist/PLpPPrzGMnMUlrO3YdhQC5OuLSIvxS8Gec/"
N12 = "plugin://plugin.video.youtube/playlist/PLIQm6xoobT2pTUH16L-Mzj1wygfjcNJbB/"
N13 = "plugin://plugin.video.youtube/playlist/PL48654284EEAE026A/"



def full_concerts1(params):
    logo=logos_guitar.logo_10(params)

    
    plugintools.add_item( 
        title="My favourites concerts",
        url=N0,
        thumbnail=logo, folder=True ) 
    
    plugintools.add_item( 
        title="Concerts I",
        url=N1,
        thumbnail=logo, folder=True ) 
    
    
    plugintools.add_item( 
        title="Concerts II",
        url=N2,
        thumbnail=logo, folder=True ) 
    
    
    
    plugintools.add_item( 
        title="Concerts III",
        url=N7,
        thumbnail=logo, folder=True ) 
 
    
    
    plugintools.add_item( 
        title="Concerts IV",
        url=N12,
        thumbnail=logo, folder=True ) 

    
    plugintools.add_item( 
        title="Concerts V",
        url=N13,
        thumbnail=logo, folder=True )    
       
    plugintools.add_item( 
        title="Symphonic Metal Bands Live Concerts",
        url=N8,
        thumbnail=logo, folder=True )     
      
    plugintools.add_item( 
        title="Thrash Metal Concerts I",
        url=N3,
        thumbnail=logo, folder=True ) 
    
        
    
    plugintools.add_item( 
        title="Thrash Metal Concerts II",
        url=N9,
        thumbnail=logo, folder=True )     

    
    plugintools.add_item( 
        title="Death Metal Concerts",
        url=N10,
        thumbnail=logo, folder=True )     
            


    plugintools.add_item( 
        title="Black Metal Live Shows I",
        url=N4,
        thumbnail=logo, folder=True ) 
   
        
    plugintools.add_item( 
        title="Black Metal Live Shows II",
        url=N11,
        thumbnail=logo, folder=True )     


        
    plugintools.add_item( 
        title="Metal - Melodic Rock - Full Concerts 1",
        url=N5,
        thumbnail=logo, folder=True ) 
    
        
    plugintools.add_item( 
        title="Metal - Melodic Rock - Full Concerts 2",
        url=N6,
        thumbnail=logo, folder=True ) 
                        
