# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_guitar

L1 = "plugin://plugin.video.youtube/playlist/PLy8LfIp6j3aKoPnnqTixxNBrF0a4TQCtX/"



def function(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="Tutorials/Playthroughs from Metal Blade Records' Artists",
        url=L1,
        thumbnail=logo, folder=True )  


