# -*- coding: utf-8 -*-
#------------------------------------------------------------

import plugintools

from logos import logos_guitar

N1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvSu3UQaHRVbV5d5KVHUb7g/"



def pt_nervosa1(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="Perpetual Chaos Album",
        url=N1,
        thumbnail=logo, folder=True )  


