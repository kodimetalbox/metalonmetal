import plugintools
#from logos import logos_bands

from logos import logos_labels


L1  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5N6V0b6WGcTSWI2AMUkHhmM/"
L2  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5PtzG-76uqWQfCMJ2Lw4Ir1/"
L3  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5Ob6yhBJlE9SHHqNbESeXpj/"
L4  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5MXbC3IlD8u28OvnY3Eva66/"


L6  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5PI0LZnTEHunbT8iEAJiwF3/"
L7  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5OPHe5PoW80NtE73x3NLMaX/"
L8  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5NdlsoqZnbq6Qap39efPtNe/"
L9  = "plugin://plugin.video.youtube/playlist/PL6_qhP3eWX5NwlUSv7BBVPQeF-zl6Zhnb/"


def function(params):
    logo=logos_labels.earache(params)
        
    plugintools.add_item( 
        title="New Earache Releases",
        url=L3,
        thumbnail=logo, folder=True )  

 
    plugintools.add_item( 
        title="Earache's New Breed",
        url=L6,
        thumbnail=logo, folder=True )  

        
    plugintools.add_item( 
        title="Old School Earache Classics ",
        url=L8,
        thumbnail=logo, folder=True )  
        
        
    plugintools.add_item( 
        title="Earache Bands Doing Covers (Official Audio)",
        url=L7,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Earache's 25th Anniversary playlist",
        url=L1,
        thumbnail=logo, folder=True )  

    plugintools.add_item( 
        title="Earache's Download 2015 playlist!",
        url=L2,
        thumbnail=logo, folder=True )  


    plugintools.add_item( 
        title="Earache Records #BlackFriday Playlist!",
        url=L4,
        thumbnail=logo, folder=True )  
        





    plugintools.add_item( 
        title="Brutal metal vocalists",
        url=L9,
        thumbnail=logo, folder=True )  
        
 
        
 
