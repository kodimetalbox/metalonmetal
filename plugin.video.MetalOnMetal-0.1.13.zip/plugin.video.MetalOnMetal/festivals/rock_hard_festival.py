import plugintools
from logos import logos_festivals

LISTA1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGv8ITfSrSNCYmLUMBEcy8Ts/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGv7VWjTOHy6UiMm3rxv-xdV/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGsCTTkHaSPFz-7x2ik4-2Gv/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvucvnCyQXvVFeT4B2K6xhZ/" 
LISTA5 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGunqDi6b3uUDAhyUlre_ZA-/" 
LISTA6 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGt2GRHWVpWKrG_dYRzbXqYL/" 
LISTA7 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGut5Ug_NjXmbHcBVqepdaNl/" 
LISTA8 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGu70qzFhjvIioqSYHBscElN/" 
LISTA9 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvUPrfTK1Pif0Lbl2KLAcJu/" 
LISTA10 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGu3VSpYYQZIdGQZ52Hue016/" 
LISTA11 = "plugin://plugin.video.youtube/playlist//" 


def rock_hard_festival1(params):
    logo=logos_festivals.rock_hard_festival(params)

    plugintools.add_item( 
        title="Rock Hard Festival 2019",
        url=LISTA3,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="Rock Hard Festival 2018",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Rock Hard Festival 2017",
        url=LISTA1,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Rock Hard Festival 2016",
        url=LISTA4,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Rock Hard Festival 2015",
        url=LISTA5,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Rock Hard Festival 2014",
        url=LISTA6,
        thumbnail=logo, folder=True )
                
    plugintools.add_item( 
        title="Rock Hard Festival 2013",
        url=LISTA7,
        thumbnail=logo, folder=True )

        
    plugintools.add_item( 
        title="Rock Hard Festival 2012",
        url=LISTA8,
        thumbnail=logo, folder=True )        

        
    plugintools.add_item( 
        title="Rock Hard Festival 2011",
        url=LISTA10,
        thumbnail=logo, folder=True )    
                       
        
    plugintools.add_item( 
        title="Rock Hard Festival 2010",
        url=LISTA9,
        thumbnail=logo, folder=True )    
        

               
