import plugintools
from logos import logos_festivals

LISTA1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuSiBO1Et3LvZXdAvqKP1UH/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuOwIGgQp4h2ddpFrei8ijK/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGs0ICanv7SJHg0qdydvmidE/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGv084aQVT6hTPywta16US6L/" 
 


def rockstadt_fest1(params):
    logo=logos_festivals.rockstadt_fest(params)

    plugintools.add_item( 
        title="RockStadt Extreme Fest 2017",
        url=LISTA1,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="RockStadt Extreme Fest 2016",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="RockStadt Extreme Fest 2015",
        url=LISTA3,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="RockStadt Extreme Fest 2014",
        url=LISTA4,
        thumbnail=logo, folder=True )
               

   
        

               
