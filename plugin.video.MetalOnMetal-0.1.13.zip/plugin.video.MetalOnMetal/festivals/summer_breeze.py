import plugintools
from logos import logos_festivals

LISTA1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGtzJ35j2DR2ex37FF3deNAY/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuZ4nfBggf5FuJCGqzzOv93/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvWHxUet6WD9xOrOz_Dof4P/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvZete56hgSqUUu2tuknT2f/" 
LISTA5 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGte_CIsxhidwnqoj4pIHdDD/" 
 


def summer_breeze1(params):
    logo=logos_festivals.summer_breeze(params)

    plugintools.add_item( 
        title="Summer Breeze 2019",
        url=LISTA1,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="Summer Breeze 2018",
        url=LISTA2,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Summer Breeze 2017",
        url=LISTA3,
        thumbnail=logo, folder=True )
        
    plugintools.add_item( 
        title="Summer Breeze 2005",
        url=LISTA4,
        thumbnail=logo, folder=True )
               
    plugintools.add_item( 
        title="Summer Breeze 2002",
        url=LISTA5,
        thumbnail=logo, folder=True )
        
   
        

               
