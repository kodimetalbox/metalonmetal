import plugintools

from logos import logos_guitar

DOC1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGucFZnKqA8kyIYewySXWrN_/"



def metallica_doc(params):
    logo=logos_guitar.logo_06(params)
    
    plugintools.add_item( 
        title="History",
        url=DOC1,
        thumbnail=logo, folder=True )  
    


