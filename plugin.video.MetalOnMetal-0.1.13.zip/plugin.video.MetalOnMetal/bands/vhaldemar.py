# -*- coding: utf-8 -*-
#------------------------------------------------------------
import plugintools
from logos import logos_bands


LISTA1 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGt-dFj-_r0_IRo5yLOO_gTi/" 
LISTA2 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGs6D_KpRxi5PBjmK1d4PqGI/" 
LISTA3 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGvgGWAbfh94EuOzZjw0huV8/" 
LISTA4 = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGuUtzbBsUZbfofKD4UBvmKh/" 


def vhaldemar1(params):
    logo=logos_bands.vhaldemar(params)

        
    plugintools.add_item( 
        title="Official Videos",
        url=LISTA4,
        thumbnail=logo, folder=True )
		
    plugintools.add_item( 
        title="Live Shows",
        url=LISTA2,
        thumbnail=logo, folder=True )
                              
    plugintools.add_item( 
        title="Live Evoken Fest 2018 Ebisu",
        url=LISTA1,
        thumbnail=logo, folder=True )

    plugintools.add_item( 
        title="Video Clips Lives Shows",
        url=LISTA3,
        thumbnail=logo, folder=True )

