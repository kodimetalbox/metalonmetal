import plugintools

def faccept3(params):
    from  bands import accept3
    accept3.accept33(params)
  


def menu1(params):
    ACCEPT=""
    plugintools.add_item(action="faccept3",title="Accept3", thumbnail=ACCEPT, folder=True )  
