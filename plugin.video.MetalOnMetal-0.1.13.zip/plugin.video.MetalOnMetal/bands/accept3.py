import plugintools

LIVE_SHOWS = "plugin://plugin.video.youtube/playlist/PLGuhlLazJwGsqskC5RY0qt8Pk0xclK14f/"


def accept33(params):
    logo=""
    plugintools.add_item( 
        title="Live Shows",
        url=LIVE_SHOWS,
        thumbnail=logo,folder=True )
        
        


