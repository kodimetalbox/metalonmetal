def wacken(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE=w1200-h800-no"
   
def hellfest(params):    
    return "https://lh3.googleusercontent.com/pw/ACtC-3c4lz60GGELnzyZ_kPFs548d6X_vlMspbpLn5liLWoGwT8U_pQDVvYO2RoHqOsbV0hLKYXT4_oO9ehmrWaLXEYWbuQJxbJA0ZVggIefLLbC-VppPa98ypOgRm9w8u8cvii7sdQpIvCDw4EgYzRxCzk=w1344-h950-no"
    
def resurrection(params):    
    return "https://lh3.googleusercontent.com/pw/ACtC-3ew8L6S5j_M9g90AlaCSnV6U5etsCJPXkgfalx8MBNgkMUhIV8KNfXCu334KP16Mp6CJsTHzu2Jx9t-Jp29GwSg67e8HJXq1cuW-bKwFFk7vYc08-JU_0vexR7Bx_kUY1aItYXnepYhFEXmhIKMRl38=w1689-h950-no"
    
def rock_hard_festival(params):    
    return "https://lh3.googleusercontent.com/pw/ACtC-3dQHPWryRpDc9-tLwrNNZCLh8y0mSiePhVeDlPu4RatzImelUDsN4XvvvPQFTnlH0E43IUT_zOTKBNyKhYsk_QnkiTZIrqg8GuYMS-p3AdrVge24Twn0Z0Cl2CqUwiu0ls4da3ezaaVeohwHiM91xV_=s400-no"
    
def summer_breeze(params):    
    return "https://lh3.googleusercontent.com/pw/ACtC-3d-XX_QlV5FnaC_ajCz8T9vTZ6wzmUcdfw6n3IqowViOADUze9Y6dOxOih9ErtbFBUasdMCbNrXN7dhppeGDy0tJ_ZeUxRozTBJOBpQ8xwPRT2mp5M5y8P3IdXgRE0ElQAYo6p74urDPiUc86-6rbWB=w892-h800-no"

def rockstadt_fest(params):    
    return "https://lh3.googleusercontent.com/pw/ACtC-3fjMKG_IWPowfkwq4SXqsSmyqnR37LgYtz-FPKeO71wC1dFmPMlqU0r2YoGYNGy4Sur4yq-QXJWGoqNepao87yDHRTqj4_8SnHXaIULfuIX_A0cFmxYEC9rqGW6PflnKr5AVbSBBSopC9N5XIN8gI0u=w644-h474-no"
    
def bloodstock(params):    
    return "https://lh3.googleusercontent.com/pw/ACtC-3fuN5TAHnF-E5wT9MRr0xBXbrkgR1ppTLffMkO8hzIl9tsi__9ahahQAUNy1NWpbi-Ag5SUo1FyrnF2YCHze4yHOf6O9h22ZecLL1kRuPjp-wWRQaSjirfRKhaN-8StBrKPqsSrogolOreYR2AIZeAU=w667-h600-no"
