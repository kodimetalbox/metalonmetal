import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_festivals


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="


id_YEAR_2020 = "PLS7iEf0zVCy09SDil5kqb_dO1PKmSV7Tu"
id_YEAR_2019 = "PLS7iEf0zVCy2z9Ny1X0R2tZMHE4F6rL11"
id_YEAR_2018 = "PLS7iEf0zVCy0f_obllTKr_CpivVyTarKm"
id_YEAR_2017 = "PLS7iEf0zVCy13ZyWSou-cMJA3eEn3JkpW"
id_YEAR_2016 = "PLS7iEf0zVCy2E3NblQ5m-FI83b653Jkb_"
id_YEAR_2015 = "PLS7iEf0zVCy0UqBGj1-ZxNaxOPDKrtmu3"
id_YEAR_2014 = "PLS7iEf0zVCy1ioBPyUAJKuQjQEbtCndC9"
id_EXODUS = "PLS7iEf0zVCy3vlXGVhkfMgIx982OaLU9N"
id_BIOHAZARD = "PLS7iEf0zVCy0JEkOgqFyVT0g6-aEi-_Oj"
id_LAMBOFGOD = "PLS7iEf0zVCy2ZLHLy4fBxgIN23yU93uHl"
id_TRIVIUM = "PLS7iEf0zVCy1iCs4pYl2Wf6FWSqcQQ9kr"
id_YEAR_2012 = "PLS7iEf0zVCy0cOjy_R27hltRkiBS1cr-I"


if usa_duffyou:  ##Usamos plugin Duff You
    YEAR_2020 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2020).encode('utf-8')).decode('utf-8')
    YEAR_2019 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2019).encode('utf-8')).decode('utf-8')
    YEAR_2018 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2018).encode('utf-8')).decode('utf-8')
    YEAR_2017 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2017).encode('utf-8')).decode('utf-8')
    YEAR_2016 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2016).encode('utf-8')).decode('utf-8')
    YEAR_2015 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2015).encode('utf-8')).decode('utf-8')
    YEAR_2014 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2014).encode('utf-8')).decode('utf-8')
    EXODUS = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_EXODUS).encode('utf-8')).decode('utf-8')
    BIOHAZARD = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_BIOHAZARD).encode('utf-8')).decode('utf-8')
    LAMBOFGOD = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_LAMBOFGOD).encode('utf-8')).decode('utf-8')   
    TRIVIUM = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_TRIVIUM).encode('utf-8')).decode('utf-8')
    YEAR_2012 = "plugin://plugin.video.duffyou/?" + base64.b64encode(base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_YEAR_2012).encode('utf-8')).decode('utf-8') 
else:  ##Usamos pluin YouTube
    YEAR_2020 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2020)	
    YEAR_2019 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2019)
    YEAR_2018 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2018)	
    YEAR_2017 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2017)
    YEAR_2016 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2016)	
    YEAR_2015 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2015)
    YEAR_2014 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2014)	
    EXODUS =  youtube.replace("MI-ID-PLAYLIST" , id_EXODUS)
    BIOHAZARD =  youtube.replace("MI-ID-PLAYLIST" , id_BIOHAZARD)	
    LAMBOFGOD =  youtube.replace("MI-ID-PLAYLIST" , id_LAMBOFGOD)
    TRIVIUM =  youtube.replace("MI-ID-PLAYLIST" , id_TRIVIUM)	
    YEAR_2012 =  youtube.replace("MI-ID-PLAYLIST" , id_YEAR_2012)
    
def playlists(params):
    logo=logos_festivals.resurrection(params)  

    plugintools.add_item( 
        title="Resurrection 2020",
        url=YEAR_2020,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        title="Resurrection 2019",
        url=YEAR_2019,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        title="Resurrection 2018",
        url=YEAR_2018,
        thumbnail=logo, folder=True ) 
        
    plugintools.add_item( 
        title="Resurrection 2017",
        url=YEAR_2017,
        thumbnail=logo, folder=True ) 
        
    plugintools.add_item( 
        title="Resurrection 2016",
        url=YEAR_2016,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        title="Resurrection 2015",
        url=YEAR_2015,
        thumbnail=logo, folder=True ) 
        
    plugintools.add_item( 
        title="Resurrection 2014",
        url=YEAR_2014,
        thumbnail=logo, folder=True ) 

    plugintools.add_item( 
        title="Resurrection 2013 Exodus",
        url=EXODUS,
        thumbnail=logo, folder=True ) 
        
    plugintools.add_item( 
        title="Resurrection 2013 Biohazard",
        url=BIOHAZARD,
        thumbnail=logo, folder=True ) 
        
    plugintools.add_item( 
        title="Resurrection 2013  Lamb of God",
        url=LAMBOFGOD,
        thumbnail=logo, folder=True ) 
       
    plugintools.add_item( 
        title="Resurrection 2013 Trivium",
        url=TRIVIUM,
        thumbnail=logo, folder=True ) 
        
    plugintools.add_item( 
        title="Resurrection 2012",
        url=YEAR_2012,
        thumbnail=logo, folder=True ) 
        

                
        
